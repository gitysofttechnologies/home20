import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateEffectiveMonthlyPrice,
  calculateOrderTotal,
  formatCurrency,
  calculateCompetitorSavings,
  filterLeads,
} from './pricing';
import { LeadRecord } from '../types';

test('calculateEffectiveMonthlyPrice applies 10% discount on yearly cycle', () => {
  const monthly = calculateEffectiveMonthlyPrice(100, 'monthly');
  assert.equal(monthly, 100);

  const yearly = calculateEffectiveMonthlyPrice(100, 'yearly', 10);
  assert.equal(yearly, 90);

  const businessYearly = calculateEffectiveMonthlyPrice(199.99, 'yearly', 10);
  assert.equal(businessYearly, 179.99);
});

test('calculateOrderTotal computes subtotal, 18% GST and savings correctly', () => {
  const monthlyOrder = calculateOrderTotal(100, 'monthly', {});
  assert.equal(monthlyOrder.subtotal, 100);
  assert.equal(monthlyOrder.taxes, 18);
  assert.equal(monthlyOrder.total, 118);
  assert.equal(monthlyOrder.savings, 0);

  const yearlyWithAddons = calculateOrderTotal(100, 'yearly', {
    dedicatedIp: true, // +149/mo
    domainRegistration: { isSelected: true, price: 75 }, // +75 one-time
  });
  // Effective monthly base = 90. Base 12mo = 1080. Dedicated IP = 149 * 12 = 1788. Domain = 75.
  // Subtotal = 1080 + 1788 + 75 = 2943.
  assert.equal(yearlyWithAddons.subtotal, 2943);
  assert.equal(yearlyWithAddons.taxes, Math.round(2943 * 0.18 * 100) / 100);
  assert.equal(yearlyWithAddons.savings, 120); // 1200 - 1080 = 120
});

test('formatCurrency formats INR and USD properly', () => {
  assert.equal(formatCurrency(199.99, 'INR'), '₹199.99');
  assert.match(formatCurrency(199.99, 'USD'), /^\$\d+\.\d{2}$/);
});

test('calculateCompetitorSavings calculates accurate percentage', () => {
  // Gitysoft starting ₹69 vs GoDaddy ₹199
  const godaddySavings = calculateCompetitorSavings(69, 199);
  assert.equal(godaddySavings, 65);

  // Gitysoft ₹69 vs Bluehost ₹299
  const bluehostSavings = calculateCompetitorSavings(69, 299);
  assert.equal(bluehostSavings, 77);
});

test('filterLeads filters records by category and region accurately', () => {
  const sampleLeads: LeadRecord[] = [
    {
      id: '1',
      businessName: 'The Taj Mahal Palace',
      category: 'Hotels & Hospitality',
      phone: '+91 22 6665-XXXX',
      rating: 4.9,
      reviewsCount: '12.4k',
      region: 'Mumbai',
      status: 'Verified',
    },
    {
      id: '2',
      businessName: 'Grand Hyatt Hotel',
      category: 'Hotels & Hospitality',
      phone: '+91 22 6676-XXXX',
      rating: 4.8,
      reviewsCount: '8.9k',
      region: 'Mumbai',
      status: 'Verified',
    },
    {
      id: '3',
      businessName: 'CloudMatrix Tech',
      category: 'IT & Software',
      phone: '+91 20 6721-XXXX',
      rating: 4.9,
      reviewsCount: '6.7k',
      region: 'Pune',
      status: 'Verified',
    },
  ];

  const filtered = filterLeads(sampleLeads, 'Hotels', 'Mumbai');
  assert.equal(filtered.length, 2);

  const puneLeads = filterLeads(sampleLeads, 'All', 'Pune');
  assert.equal(puneLeads.length, 1);
  assert.equal(puneLeads[0].businessName, 'CloudMatrix Tech');
});
