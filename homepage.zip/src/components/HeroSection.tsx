import React, { useState } from 'react';
import { SAMPLE_LEADS } from '../data/hostingData';
import { LeadRecord, Currency } from '../types';
import { filterLeads, formatCurrency } from '../utils/pricing';
import {
  Globe,
  Server,
  Cpu,
  Mail,
  Layout,
  TrendingUp,
  MessageSquare,
  Smartphone,
  Palette,
  Code2,
  Lock,
  Download,
  Play,
  CheckCircle2,
  Star,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

interface HeroSectionProps {
  currency: Currency;
  onOpenCheckout: (planName: string, price: number) => void;
  onOpenDomainSearch: () => void;
  onSelectService: (serviceName: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  currency,
  onOpenCheckout,
  onOpenDomainSearch,
  onSelectService,
}) => {
  const [category, setCategory] = useState('Hotels & Hospitality');
  const [region, setRegion] = useState('Mumbai & Pune');
  const [isExtracting, setIsExtracting] = useState(false);
  const [progress, setProgress] = useState(100);
  const [recordsCount, setRecordsCount] = useState(1480);
  const [leadsList, setLeadsList] = useState<LeadRecord[]>(SAMPLE_LEADS);

  const handleExtract = () => {
    setIsExtracting(true);
    setProgress(15);
    setTimeout(() => setProgress(50), 300);
    setTimeout(() => setProgress(85), 600);
    setTimeout(() => {
      setProgress(100);
      setIsExtracting(false);
      const newCount = 1480 + Math.floor(Math.random() * 200);
      setRecordsCount(newCount);
      // Filter leads according to selected category
      const filtered = filterLeads(SAMPLE_LEADS, category === 'All' ? undefined : category);
      setLeadsList(filtered.length > 0 ? filtered : SAMPLE_LEADS);
    }, 900);
  };

  const handleExportExcel = () => {
    // Generate real downloadable CSV file for client lead data
    const headers = 'Business Name,Category,Phone,Rating,Reviews,Region,Status\n';
    const rows = leadsList
      .map(
        (l) =>
          `"${l.businessName}","${l.category}","${l.phone}","${l.rating}","${l.reviewsCount}","${l.region}","${l.status}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Gitysoft_GMB_Leads_${category.replace(/\s+/g, '_')}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const quickServices = [
    { name: 'Domain Registration', price: 'Starting ₹75/yr', icon: Globe, anchor: '#domains' },
    { name: 'Web Hosting', price: 'Starting ₹69/mo', icon: Server, anchor: '#hosting-plans' },
    { name: 'VPS & Dedicated Server', price: 'Starting ₹449/mo', icon: Cpu, isHot: true, anchor: '#cloud-vps' },
    { name: 'Business Email', price: 'Starting ₹59/mo', icon: Mail, anchor: '#architecture' },
    { name: 'Website Designing', price: 'Starting ₹4,999', icon: Layout, anchor: '#digital-services' },
    { name: 'Digital Marketing', price: 'Starting ₹3,999/mo', icon: TrendingUp, anchor: '#digital-services' },
    { name: 'Bulk SMS', price: 'Starting 14p/SMS', icon: MessageSquare, anchor: '#digital-services' },
    { name: 'Bulk WhatsApp', price: 'Starting 79p/msg', icon: Smartphone, isHot: true, anchor: '#digital-services' },
    { name: 'Canva Pro Tools', price: 'Starting ₹199/yr', icon: Palette, anchor: '#digital-services' },
    { name: 'Software Development', price: 'Custom Quote', icon: Code2, anchor: '#why-choose' },
    { name: 'SSL Certificates', price: 'Free to ₹499/yr', icon: Lock, anchor: '#architecture' },
  ];

  return (
    <section className="relative pt-8 pb-16 bg-white overflow-hidden border-b border-slate-200">
      {/* Background Subtle Grid Pattern matching Screenshot 14 */}
      <div className="absolute inset-0 bg-grid-pattern opacity-60 pointer-events-none" />
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-100/40 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-emerald-100/30 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left Column: Headlines & Call to Actions */}
          <div className="lg:col-span-6 space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-pink-50 border border-pink-200 text-pink-700 text-xs font-bold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-pink-600" /> Enterprise Engineering
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.12]">
              Best Software{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-500">
                Company in India
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-600 max-w-xl leading-relaxed">
              Custom ERP, CRM, mobile applications, and SaaS platforms built with modern React, Node, Python, and
              scalable microservices architectures on Tier-4 low-latency infrastructure.
            </p>

            {/* Feature Badges */}
            <div className="flex flex-wrap gap-2.5 pt-1">
              {['Custom ERP/CRM', 'React & Next.js', 'Mobile Apps', 'Fintech APIs'].map((tag) => (
                <div
                  key={tag}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-blue-50/70 border border-blue-200 text-blue-800 text-xs font-semibold"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                  {tag}
                </div>
              ))}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={() => onOpenCheckout('Custom Enterprise Engineering', 4999)}
                className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-sm shadow-lg shadow-purple-600/25 hover:shadow-xl transition-all flex items-center gap-2 active:scale-95"
              >
                Custom Development <ArrowRight className="w-4 h-4" />
              </button>

              <a
                href="#price-comparison"
                className="px-6 py-3.5 rounded-xl bg-white border border-slate-300 hover:border-slate-400 text-slate-800 hover:text-slate-950 font-bold text-sm shadow-xs hover:shadow-sm transition-all flex items-center gap-2"
              >
                🏷 Compare Pricing
              </a>
            </div>
          </div>

          {/* Right Column: Interactive GMB Scraper Tool Mockup (Screenshot 14) */}
          <div className="lg:col-span-6">
            <div className="bg-slate-900 rounded-2xl p-3 sm:p-4 shadow-2xl border border-slate-800 text-white relative">
              {/* Laptop top bar */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-red-500 inline-block" />
                  <span className="w-3 h-3 rounded-full bg-yellow-500 inline-block" />
                  <span className="w-3 h-3 rounded-full bg-green-500 inline-block" />
                </div>
                <div className="bg-slate-800/80 px-3 py-1 rounded text-slate-400 text-[11px] font-mono flex items-center gap-1.5 border border-slate-700 truncate max-w-xs">
                  <Lock className="w-3 h-3 text-emerald-400" />
                  https://tools.gitysoft.com/gmb-scraper
                </div>
                <span className="text-[11px] font-semibold text-blue-400 bg-blue-950/80 px-2 py-0.5 rounded border border-blue-800">
                  8. GMB Scraper Tool
                </span>
              </div>

              {/* Tool Internal Canvas */}
              <div className="bg-slate-950/90 rounded-xl p-3 sm:p-4 mt-3 border border-slate-800">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">🗂</span>
                    <span className="text-xs sm:text-sm font-bold text-slate-200">
                      GMB Local Business Data Extractor v4.2
                    </span>
                  </div>
                  <div className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-[11px] font-mono font-bold px-2 py-0.5 rounded-full">
                    {recordsCount.toLocaleString()} Verified Records
                  </div>
                </div>

                {/* Interactive Controls */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1 pb-3 text-xs">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Business Category</label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-2.5 py-1.5 text-xs focus:ring-1 focus:ring-emerald-500 outline-hidden"
                    >
                      <option value="Hotels & Hospitality">Hotels & Hospitality</option>
                      <option value="IT & Software">IT & Software</option>
                      <option value="Fintech & Banking">Fintech & Banking</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Target Region</label>
                    <select
                      value={region}
                      onChange={(e) => setRegion(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 text-slate-200 rounded-lg px-2.5 py-1.5 text-xs focus:ring-1 focus:ring-emerald-500 outline-hidden"
                    >
                      <option value="Mumbai & Pune">Mumbai & Pune</option>
                      <option value="Bangalore">Bangalore</option>
                      <option value="Delhi-NCR">Delhi-NCR</option>
                    </select>
                  </div>
                  <div className="flex items-end">
                    <button
                      onClick={handleExtract}
                      disabled={isExtracting}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50 text-xs"
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      {isExtracting ? 'Extracting...' : 'Extract Leads'}
                    </button>
                  </div>
                </div>

                {/* Progress bar */}
                {isExtracting && (
                  <div className="w-full bg-slate-800 rounded-full h-1.5 mb-2 overflow-hidden">
                    <div
                      className="bg-emerald-500 h-1.5 rounded-full transition-all duration-300"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                )}

                {/* Live Extracted Leads Table */}
                <div className="overflow-x-auto rounded-lg border border-slate-800">
                  <table className="w-full text-left text-[11px]">
                    <thead className="bg-slate-900 text-slate-400 font-semibold border-b border-slate-800">
                      <tr>
                        <th className="py-1.5 px-2.5">Business Name</th>
                        <th className="py-1.5 px-2.5">Phone Number</th>
                        <th className="py-1.5 px-2.5">Rating</th>
                        <th className="py-1.5 px-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/80 text-slate-300">
                      {leadsList.slice(0, 3).map((item) => (
                        <tr key={item.id} className="hover:bg-slate-900/60 transition-colors">
                          <td className="py-2 px-2.5 font-medium text-white">{item.businessName}</td>
                          <td className="py-2 px-2.5 text-blue-400 font-mono">{item.phone}</td>
                          <td className="py-2 px-2.5">
                            <span className="flex items-center gap-1 text-amber-400 font-semibold">
                              <Star className="w-3 h-3 fill-amber-400" /> {item.rating} ({item.reviewsCount})
                            </span>
                          </td>
                          <td className="py-2 px-2.5">
                            <span className="bg-emerald-950 text-emerald-400 border border-emerald-800/60 px-1.5 py-0.5 rounded text-[10px]">
                              {item.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Footer Controls */}
                <div className="flex items-center justify-between pt-3 text-[11px] text-slate-400 border-t border-slate-800/80 mt-2">
                  <span className="font-mono">
                    Processed {recordsCount} of {recordsCount} Entities
                  </span>
                  <button
                    onClick={handleExportExcel}
                    className="flex items-center gap-1 text-blue-400 hover:text-blue-300 font-semibold bg-blue-950/60 hover:bg-blue-900/80 px-2.5 py-1 rounded border border-blue-800/50 transition-colors"
                  >
                    <Download className="w-3 h-3" /> Export to Excel (.xlsx)
                  </button>
                </div>
              </div>

              {/* Bottom status */}
              <div className="flex items-center justify-between pt-2 px-2 text-[10px] text-slate-500">
                <span>Google My Business Lead Scraper Tool</span>
                <span className="flex items-center gap-1.5 text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> Auto Active
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* 11-Service Quick Access Icon Strip (Screenshot 14 bottom) */}
        <div className="mt-14 pt-8 border-t border-slate-200">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-11 gap-3">
            {quickServices.map((service, idx) => {
              const IconComp = service.icon;
              return (
                <a
                  key={idx}
                  href={service.anchor}
                  onClick={() => onSelectService(service.name)}
                  className="group relative flex flex-col items-center text-center p-3 rounded-2xl bg-white hover:bg-blue-50/50 border border-slate-200/90 hover:border-blue-400 hover:shadow-md transition-all duration-200"
                >
                  {service.isHot && (
                    <span className="absolute -top-2 px-1.5 py-0.2 bg-amber-500 text-slate-950 font-extrabold text-[9px] rounded-full uppercase tracking-wider shadow-xs">
                      🔥 HOT
                    </span>
                  )}
                  <div className="w-10 h-10 rounded-xl bg-slate-50 group-hover:bg-blue-600 group-hover:text-white text-slate-700 flex items-center justify-center mb-2 transition-colors duration-200">
                    <IconComp className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-bold text-slate-900 line-clamp-1 group-hover:text-blue-600 transition-colors">
                    {service.name}
                  </span>
                  <span className="text-[10px] text-slate-500 mt-0.5 font-medium">{service.price}</span>
                </a>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};
