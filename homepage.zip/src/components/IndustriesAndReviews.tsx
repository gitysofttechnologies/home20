import React, { useState } from 'react';
import { TESTIMONIALS } from '../data/hostingData';
import { Testimonial } from '../types';
import {
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Star,
  Quote,
  CheckCircle2,
  Building2,
  ArrowRight,
} from 'lucide-react';

export const IndustriesAndReviews: React.FC = () => {
  const [activeReviewIdx, setActiveReviewIdx] = useState(0);

  const brands = [
    { name: 'Google Cloud', type: 'Enterprise Cloud', icon: '☁️' },
    { name: 'Shopify', type: 'Ecommerce Platform', icon: '🛍️' },
    { name: 'Zomato', type: 'Food & Quick Commerce', icon: '🍽️' },
    { name: 'Zoho', type: 'Cloud Business SaaS', icon: '📊' },
    { name: 'WordPress', type: 'CMS & Web Development', icon: '🌐' },
    { name: 'Razorpay', type: 'Fintech & UPI Gateway', icon: '💳' },
  ];

  const currentTestimonial: Testimonial = TESTIMONIALS[activeReviewIdx];

  const handleNext = () => {
    setActiveReviewIdx((prev) => (prev + 1) % TESTIMONIALS.length);
  };

  const handlePrev = () => {
    setActiveReviewIdx((prev) => (prev - 1 + TESTIMONIALS.length) % TESTIMONIALS.length);
  };

  return (
    <section className="py-20 bg-white border-b border-slate-200 relative overflow-hidden">
      {/* Background Grid Pattern (Screenshot 6) */}
      <div className="absolute inset-0 bg-grid-pattern opacity-40 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Top Section: Industries We Serve */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-bold uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" /> Industry Leaders &amp; Trusted Brands
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900">
              Industries We Serve
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600 max-w-2xl">
              Powering high-growth digital infrastructure for 10,000+ businesses across e-commerce, fintech, cloud SaaS,
              and healthcare.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <span className="text-xs text-slate-400 font-medium mr-1">Step Navigation</span>
            <button
              onClick={handlePrev}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
              aria-label="Previous testimonial"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNext}
              className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
              aria-label="Next testimonial"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Brand Logos Strip matching Screenshot 6 */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-20">
          {brands.map((b, idx) => (
            <div
              key={idx}
              className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-xs hover:shadow-md transition-all flex items-center gap-3"
            >
              <span className="text-xl">{b.icon}</span>
              <div className="overflow-hidden">
                <div className="text-xs font-bold text-slate-900 flex items-center gap-1">
                  <span className="truncate">{b.name}</span>
                  <CheckCircle2 className="w-3 h-3 text-blue-600 shrink-0" />
                </div>
                <div className="text-[10px] text-slate-500 truncate">{b.type}</div>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Section: What Our Customers Say (Screenshot 6) */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h3 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900">
            What Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-indigo-600">Customers</span> Say
          </h3>
          <p className="mt-3 text-xs sm:text-sm text-slate-600">
            Real feedback and ratings from developers, startups, and businesses scaling on Gitysoft cloud
            infrastructure.
          </p>
        </div>

        {/* Testimonials Carousel Cards matching Screenshot 6 */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          {/* Previous Card Preview (Hidden on mobile) */}
          <div className="hidden md:block md:col-span-3 opacity-60 hover:opacity-100 transition-opacity">
            {TESTIMONIALS[(activeReviewIdx - 1 + TESTIMONIALS.length) % TESTIMONIALS.length] && (
              <div
                onClick={handlePrev}
                className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm cursor-pointer text-xs"
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-700">
                    {TESTIMONIALS[(activeReviewIdx - 1 + TESTIMONIALS.length) % TESTIMONIALS.length].name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 truncate">
                      {TESTIMONIALS[(activeReviewIdx - 1 + TESTIMONIALS.length) % TESTIMONIALS.length].name}
                    </div>
                    <div className="text-[10px] text-slate-500 truncate">
                      {TESTIMONIALS[(activeReviewIdx - 1 + TESTIMONIALS.length) % TESTIMONIALS.length].company}
                    </div>
                  </div>
                </div>
                <p className="text-slate-600 line-clamp-3 text-[11px]">
                  &ldquo;{TESTIMONIALS[(activeReviewIdx - 1 + TESTIMONIALS.length) % TESTIMONIALS.length].quote}&rdquo;
                </p>
              </div>
            )}
          </div>

          {/* Center Active Focused Testimonial Card (Screenshot 6) */}
          <div className="md:col-span-6 bg-white rounded-3xl p-6 sm:p-8 border-2 border-purple-500/80 shadow-2xl relative ring-8 ring-purple-500/5">
            <Quote className="w-10 h-10 text-purple-100 absolute top-6 right-6 pointer-events-none" />

            {/* User Meta Row */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-5">
              <div className="flex items-center gap-3.5">
                <img
                  src={currentTestimonial.avatar}
                  alt={currentTestimonial.name}
                  className="w-14 h-14 rounded-2xl object-cover border-2 border-purple-200 shadow-md"
                />
                <div>
                  <h4 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-1.5">
                    {currentTestimonial.name}
                  </h4>
                  <div className="text-xs text-slate-500">
                    {currentTestimonial.role} ·{' '}
                    <span className="font-semibold text-purple-700">{currentTestimonial.company}</span>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className="flex items-center gap-1 justify-end text-amber-400">
                  {[...Array(currentTestimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                  ))}
                </div>
                <span className="text-[10px] text-slate-400 block mt-1">
                  via {currentTestimonial.source} · {currentTestimonial.verifiedTime}
                </span>
              </div>
            </div>

            {/* Testimonial Quote */}
            <h5 className="text-base font-extrabold text-slate-900 mb-2">
              &ldquo;{currentTestimonial.quoteTitle}&rdquo;
            </h5>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
              {currentTestimonial.quote}
            </p>

            {/* Footer tags */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-4 border-t border-slate-100 text-xs">
              <span className="px-3 py-1 rounded-full text-[11px] font-bold bg-purple-50 text-purple-700 border border-purple-200">
                {currentTestimonial.categoryTag}
              </span>
              <span className="text-slate-500 text-[11px] flex items-center gap-1 font-semibold">
                📍 {currentTestimonial.location}
              </span>
            </div>
          </div>

          {/* Next Card Preview (Hidden on mobile) */}
          <div className="hidden md:block md:col-span-3 opacity-60 hover:opacity-100 transition-opacity">
            {TESTIMONIALS[(activeReviewIdx + 1) % TESTIMONIALS.length] && (
              <div
                onClick={handleNext}
                className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm cursor-pointer text-xs"
              >
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center font-bold text-slate-700">
                    {TESTIMONIALS[(activeReviewIdx + 1) % TESTIMONIALS.length].name.charAt(0)}
                  </div>
                  <div>
                    <div className="font-bold text-slate-900 truncate">
                      {TESTIMONIALS[(activeReviewIdx + 1) % TESTIMONIALS.length].name}
                    </div>
                    <div className="text-[10px] text-slate-500 truncate">
                      {TESTIMONIALS[(activeReviewIdx + 1) % TESTIMONIALS.length].company}
                    </div>
                  </div>
                </div>
                <p className="text-slate-600 line-clamp-3 text-[11px]">
                  &ldquo;{TESTIMONIALS[(activeReviewIdx + 1) % TESTIMONIALS.length].quote}&rdquo;
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Carousel indicator dots */}
        <div className="flex items-center justify-center gap-2 mt-8">
          {TESTIMONIALS.map((_, dotIdx) => (
            <button
              key={dotIdx}
              onClick={() => setActiveReviewIdx(dotIdx)}
              className={`h-2 rounded-full transition-all ${
                activeReviewIdx === dotIdx ? 'w-8 bg-purple-600' : 'w-2 bg-slate-300 hover:bg-slate-400'
              }`}
              aria-label={`Go to slide ${dotIdx + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
