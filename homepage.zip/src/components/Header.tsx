import React, { useState } from 'react';
import { Currency } from '../types';
import {
  Server,
  Phone,
  ShieldCheck,
  ChevronDown,
  Menu,
  X,
  Zap,
  Globe,
  MessageCircle,
  LogIn,
} from 'lucide-react';

interface HeaderProps {
  currency: Currency;
  setCurrency: (c: Currency) => void;
  onOpenCheckout: (planName: string, price: number) => void;
  onOpenLiveChat: () => void;
  onOpenDomainSearch: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currency,
  setCurrency,
  onOpenCheckout,
  onOpenLiveChat,
  onOpenDomainSearch,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [hostingDropdownOpen, setHostingDropdownOpen] = useState(false);

  return (
    <>
      {/* Top Notification Announcement Bar */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-purple-800 text-white text-xs sm:text-sm py-2 px-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
            <span className="bg-amber-400 text-slate-950 font-bold px-2 py-0.5 rounded text-[11px] uppercase tracking-wider shrink-0">
              Flash Deal
            </span>
            <span className="truncate">
              ⚡ Up to 70% Off Gen4 NVMe LiteSpeed Cloud + Free Domain & Wildcard SSL | Tier-4 Mumbai DC
            </span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-xs shrink-0">
            <button
              onClick={() => onOpenDomainSearch()}
              className="hover:underline flex items-center gap-1 text-blue-100 hover:text-white"
            >
              <Globe className="w-3.5 h-3.5" /> Domain Search ₹75/yr
            </button>
            <span className="text-blue-300">|</span>
            <a
              href="tel:+918004489762"
              className="hover:underline flex items-center gap-1 text-blue-100 hover:text-white"
            >
              <Phone className="w-3.5 h-3.5" /> +91 800-GITYSOFT
            </a>
            <span className="text-blue-300">|</span>
            {/* Currency Switcher */}
            <div className="flex items-center gap-1 bg-white/10 rounded px-1.5 py-0.5">
              <button
                onClick={() => setCurrency('INR')}
                className={`px-1.5 py-0.5 rounded text-[11px] font-semibold transition-colors ${
                  currency === 'INR' ? 'bg-white text-blue-900 shadow-sm' : 'text-blue-100 hover:text-white'
                }`}
              >
                ₹ INR
              </button>
              <button
                onClick={() => setCurrency('USD')}
                className={`px-1.5 py-0.5 rounded text-[11px] font-semibold transition-colors ${
                  currency === 'USD' ? 'bg-white text-blue-900 shadow-sm' : 'text-blue-100 hover:text-white'
                }`}
              >
                $ USD
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Top Navigation Bar (Strict 3-Zone Contract) */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 transition-shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-8">
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <a href="/" className="flex items-center gap-2 group">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
                <Server className="w-5 h-5" />
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-extrabold tracking-tight text-slate-900 flex items-center gap-1">
                  Gitysoft<span className="text-blue-600">.</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400">
                  Cloud Infrastructure
                </span>
              </div>
            </a>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-semibold text-slate-700">
            <div
              className="relative"
              onMouseEnter={() => setHostingDropdownOpen(true)}
              onMouseLeave={() => setHostingDropdownOpen(false)}
            >
              <a
                href="#hosting-plans"
                className="flex items-center gap-1 hover:text-blue-600 transition-colors py-2 whitespace-nowrap shrink-0"
              >
                Web Hosting <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </a>
              {hostingDropdownOpen && (
                <div className="absolute top-full left-0 w-72 bg-white rounded-xl shadow-xl border border-slate-100 p-3 py-2 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <a
                    href="#hosting-plans"
                    className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    <div className="w-8 h-8 rounded bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                      <Zap className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">LiteSpeed Web Hosting</div>
                      <div className="text-[11px] text-slate-500">From ₹99.99/mo with NVMe Gen4</div>
                    </div>
                  </a>
                  <a
                    href="#cloud-vps"
                    className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    <div className="w-8 h-8 rounded bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0">
                      <Server className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">Cloud VPS Servers</div>
                      <div className="text-[11px] text-slate-500">Dedicated AMD EPYC & Root SSH</div>
                    </div>
                  </a>
                  <a
                    href="#bare-metal"
                    className="flex items-start gap-3 p-2.5 rounded-lg hover:bg-slate-50 transition-colors"
                  >
                    <div className="w-8 h-8 rounded bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-900">Dedicated Bare Metal</div>
                      <div className="text-[11px] text-slate-500">10 Gbps unmetered port & IPMI</div>
                    </div>
                  </a>
                </div>
              )}
            </div>

            <a href="#cloud-vps" className="hover:text-blue-600 transition-colors whitespace-nowrap shrink-0">
              Cloud VPS
            </a>
            <a href="#bare-metal" className="hover:text-blue-600 transition-colors whitespace-nowrap shrink-0">
              Bare Metal
            </a>
            <a href="#digital-services" className="hover:text-blue-600 transition-colors whitespace-nowrap shrink-0">
              Services
            </a>
            <a href="#global-datacenters" className="hover:text-blue-600 transition-colors whitespace-nowrap shrink-0">
              Datacenters
            </a>
            <a href="#price-comparison" className="hover:text-blue-600 transition-colors whitespace-nowrap shrink-0">
              Comparison
            </a>
            <a href="#faq" className="hover:text-blue-600 transition-colors whitespace-nowrap shrink-0">
              FAQ
            </a>
          </nav>

          {/* Zone 3: Primary Actions */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onOpenLiveChat}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <MessageCircle className="w-3.5 h-3.5 text-blue-600" /> 24/7 Chat
            </button>

            <button
              onClick={() => onOpenCheckout('Business Hosting', 199.99)}
              className="hidden sm:inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md shadow-blue-600/20 hover:shadow-lg transition-all active:scale-95"
            >
              Get Started →
            </button>

            {/* Mobile Menu Trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="flex items-center justify-between py-2 border-b border-slate-100">
              <span className="text-xs font-semibold text-slate-500">Currency</span>
              <div className="flex items-center gap-1 bg-slate-100 rounded p-1">
                <button
                  onClick={() => setCurrency('INR')}
                  className={`px-2 py-0.5 rounded text-xs font-bold ${
                    currency === 'INR' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  ₹ INR
                </button>
                <button
                  onClick={() => setCurrency('USD')}
                  className={`px-2 py-0.5 rounded text-xs font-bold ${
                    currency === 'USD' ? 'bg-white text-blue-600 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  $ USD
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-sm font-medium text-slate-700">
              <a
                href="#hosting-plans"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-lg bg-slate-50 hover:bg-blue-50 hover:text-blue-600"
              >
                Web Hosting
              </a>
              <a
                href="#cloud-vps"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-lg bg-slate-50 hover:bg-blue-50 hover:text-blue-600"
              >
                Cloud VPS
              </a>
              <a
                href="#bare-metal"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-lg bg-slate-50 hover:bg-blue-50 hover:text-blue-600"
              >
                Bare Metal
              </a>
              <a
                href="#digital-services"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-lg bg-slate-50 hover:bg-blue-50 hover:text-blue-600"
              >
                Services
              </a>
              <a
                href="#global-datacenters"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-lg bg-slate-50 hover:bg-blue-50 hover:text-blue-600"
              >
                Datacenters
              </a>
              <a
                href="#price-comparison"
                onClick={() => setMobileMenuOpen(false)}
                className="p-2.5 rounded-lg bg-slate-50 hover:bg-blue-50 hover:text-blue-600"
              >
                Comparison
              </a>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenDomainSearch();
                }}
                className="w-full py-2.5 text-center text-xs font-bold text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl"
              >
                Find & Register Domain (from ₹75/yr)
              </button>
              <button
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenCheckout('Business Hosting', 199.99);
                }}
                className="w-full py-2.5 text-center text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md"
              >
                Get Started Now →
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
