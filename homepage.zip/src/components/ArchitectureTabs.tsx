import React, { useState } from 'react';
import { Currency } from '../types';
import {
  Server,
  Cloud,
  Cpu,
  Mail,
  Globe,
  ShieldCheck,
  Terminal,
  CheckCircle2,
  Database,
  Folder,
  ArrowRight,
  HardDrive,
  Activity,
  Plus,
  Minus,
} from 'lucide-react';

interface ArchitectureTabsProps {
  currency: Currency;
  onOpenCheckout: (planName: string, price: number) => void;
}

export const ArchitectureTabs: React.FC<ArchitectureTabsProps> = ({ onOpenCheckout }) => {
  const [activeTab, setActiveTab] = useState('web-hosting');
  const [activeConsoleTab, setActiveConsoleTab] = useState<'websites' | 'mariadb' | 'webmail' | 'files'>('websites');

  const tabs = [
    { id: 'web-hosting', name: 'Web Hosting', icon: Server },
    { id: 'vps-cloud', name: 'VPS & Cloud', icon: Cloud },
    { id: 'dedicated-servers', name: 'Dedicated Servers', icon: Cpu },
    { id: 'business-email', name: 'Business Email', icon: Mail },
    { id: 'domains-dns', name: 'Domains & DNS', icon: Globe },
    { id: 'security-ssl', name: 'Security & SSL', icon: ShieldCheck },
    { id: 'developer-tools', name: 'Developer Tools', icon: Terminal },
  ];

  return (
    <section id="architecture" className="py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900">
            Choose Your Cloud Architecture
          </h2>
          <p className="mt-3 text-base text-slate-600">
            Explore 7 distinct enterprise hosting tiers with custom hardware profiles, dedicated consoles, and 100%
            NVMe speed.
          </p>
        </div>

        {/* 7 Architecture Navigation Tabs matching Screenshot 12 */}
        <div className="flex items-center justify-start lg:justify-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`relative px-4 py-2.5 rounded-full text-xs sm:text-sm font-bold flex items-center gap-2 transition-all whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/25 ring-2 ring-blue-600/30'
                    : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200 hover:border-slate-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.name}
              </button>
            );
          })}
        </div>

        {/* Main Content Showcase Box */}
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl p-6 sm:p-8 lg:p-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Column: Plan description and benefits */}
            <div className="lg:col-span-4 space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-20 h-24 bg-slate-900 rounded-2xl p-2.5 flex flex-col justify-between shadow-lg text-white relative">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-[9px] font-mono text-emerald-400">
                      <span>LITESPEED TURBO</span>
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    </div>
                    <div className="text-[8px] font-mono text-blue-300">NVMe 7,500 MB/s</div>
                  </div>
                  <div className="flex items-center justify-between pt-1 border-t border-slate-800 text-[8px] text-slate-400">
                    <span>cPanel & SSL OK</span>
                  </div>
                  <div className="absolute -bottom-3 -right-3 w-10 h-10 rounded-full bg-blue-600 text-white font-black flex items-center justify-center text-sm shadow-md ring-4 ring-white">
                    W
                  </div>
                </div>

                <div>
                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug">
                    {activeTab === 'web-hosting' && 'Turbo NVMe Web Hosting'}
                    {activeTab === 'vps-cloud' && 'Elastic AMD EPYC Cloud VPS'}
                    {activeTab === 'dedicated-servers' && 'Bare Metal Enterprise Compute'}
                    {activeTab === 'business-email' && 'Titan Suite Business Email'}
                    {activeTab === 'domains-dns' && 'Anycast Low-Latency DNS'}
                    {activeTab === 'security-ssl' && 'Imunify360 & Wildcard SSL'}
                    {activeTab === 'developer-tools' && 'Full Root Dev Stacks & Git'}
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    LiteSpeed-powered cPanel hosting optimized for WordPress & dynamic web applications.
                  </p>
                </div>
              </div>

              <div className="space-y-2.5 text-xs text-slate-700">
                {[
                  'Gen4 Enterprise NVMe Storage',
                  "Free Let's Encrypt Wildcard SSL",
                  'LiteSpeed Web Server + LSCache',
                  '1-Click Softaculous (400+ Apps)',
                  '24/7 Priority Indian Support',
                ].map((spec, sIdx) => (
                  <div key={sIdx} className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="font-medium">{spec}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={() => onOpenCheckout('Turbo NVMe Web Hosting', 199.99)}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold shadow-md shadow-blue-600/20 transition-all active:scale-95"
              >
                View Web Hosting Plans <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Center Column: Interactive LiteSpeed cPanel Suite Preview (Screenshot 12) */}
            <div className="lg:col-span-5 bg-slate-900 rounded-2xl p-5 border border-slate-800 text-white shadow-2xl">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-200">cPanel</span>
                  <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/40">
                    99.99% SLA
                  </span>
                </div>
                <span className="text-xs text-slate-300 font-semibold">Gitysoft cPanel Suite</span>
                <span className="flex items-center gap-1 text-[11px] text-emerald-400">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> LIVE
                </span>
              </div>

              {/* Resource Bars */}
              <div className="grid grid-cols-2 gap-3 my-4">
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <div className="text-[10px] text-slate-400 flex justify-between">
                    <span>NVMe SSD</span>
                    <span className="text-blue-400 font-mono">24.2 / 50 GB</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2">
                    <div className="bg-blue-500 h-1.5 rounded-full" style={{ width: '48%' }} />
                  </div>
                </div>

                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <div className="text-[10px] text-slate-400 flex justify-between">
                    <span>RAM Allocated</span>
                    <span className="text-purple-400 font-mono">1.2 / 4 GB</span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2">
                    <div className="bg-purple-500 h-1.5 rounded-full" style={{ width: '30%' }} />
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 mb-4 font-mono">
                <span>LiteSpeed Cache: ACTIVE</span>
                <span className="text-emerald-400 font-bold">0.18s TTFB</span>
              </div>

              {/* 4 Interactive Quick Tools */}
              <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 mb-4">
                <div className="text-[11px] font-semibold text-slate-300 mb-2">
                  LiteSpeed cPanel Management
                </div>
                <div className="grid grid-cols-4 gap-2 text-center text-[10px]">
                  <button
                    onClick={() => setActiveConsoleTab('websites')}
                    className={`p-2 rounded-lg border transition-all flex flex-col items-center gap-1 ${
                      activeConsoleTab === 'websites'
                        ? 'bg-blue-600/20 border-blue-500 text-blue-400'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Globe className="w-3.5 h-3.5" /> Websites
                  </button>
                  <button
                    onClick={() => setActiveConsoleTab('mariadb')}
                    className={`p-2 rounded-lg border transition-all flex flex-col items-center gap-1 ${
                      activeConsoleTab === 'mariadb'
                        ? 'bg-purple-600/20 border-purple-500 text-purple-400'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Database className="w-3.5 h-3.5" /> MariaDB
                  </button>
                  <button
                    onClick={() => setActiveConsoleTab('webmail')}
                    className={`p-2 rounded-lg border transition-all flex flex-col items-center gap-1 ${
                      activeConsoleTab === 'webmail'
                        ? 'bg-cyan-600/20 border-cyan-500 text-cyan-400'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Mail className="w-3.5 h-3.5" /> Webmail
                  </button>
                  <button
                    onClick={() => setActiveConsoleTab('files')}
                    className={`p-2 rounded-lg border transition-all flex flex-col items-center gap-1 ${
                      activeConsoleTab === 'files'
                        ? 'bg-amber-600/20 border-amber-500 text-amber-400'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Folder className="w-3.5 h-3.5" /> Files
                  </button>
                </div>
              </div>

              {/* Console trust badges */}
              <div className="grid grid-cols-2 gap-2 text-center text-[11px] font-semibold">
                <div className="bg-emerald-950/60 border border-emerald-800/40 text-emerald-400 p-2 rounded-lg flex items-center justify-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" /> Bank Security
                </div>
                <div className="bg-blue-950/60 border border-blue-800/40 text-blue-400 p-2 rounded-lg flex items-center justify-center gap-1.5">
                  <Activity className="w-3.5 h-3.5" /> Daily Backups
                </div>
              </div>
            </div>

            {/* Right Column: Quick Expandable Architecture Selector */}
            <div className="lg:col-span-3 space-y-2">
              {[
                { id: 'vps-cloud', label: 'VPS & Cloud Hosting', icon: Cloud },
                { id: 'dedicated-servers', label: 'Dedicated Servers', icon: Cpu },
                { id: 'business-email', label: 'Business Email', icon: Mail },
                { id: 'domains-dns', label: 'Domains & DNS', icon: Globe },
                { id: 'security-ssl', label: 'Security & SSL', icon: ShieldCheck },
                { id: 'developer-tools', label: 'Developer Tools', icon: Terminal },
              ].map((item) => {
                const Icon = item.icon;
                const isSelected = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between text-xs font-bold transition-all ${
                      isSelected
                        ? 'bg-blue-50 border-blue-400 text-blue-700 shadow-sm'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-white hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4 text-blue-600" />
                      <span>{item.label}</span>
                    </div>
                    {isSelected ? <Minus className="w-4 h-4 text-blue-600" /> : <Plus className="w-4 h-4 text-slate-400" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
