import React, { useState, useEffect } from 'react';
import { ArrowUp, MessageSquare } from 'lucide-react';

interface FloatingActionsProps {
  onOpenLiveChat: () => void;
}

export const FloatingActions: React.FC<FloatingActionsProps> = ({ onOpenLiveChat }) => {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3 pointer-events-auto">
      {/* Back to top button matching Screenshot 1 bottom right */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="w-12 h-12 rounded-full bg-slate-950 hover:bg-slate-800 text-white flex flex-col items-center justify-center text-[8px] font-black uppercase tracking-tighter shadow-2xl transition-all active:scale-95 group border border-slate-700 animate-in fade-in slide-in-from-bottom-2 duration-200"
          aria-label="Back to top"
        >
          <ArrowUp className="w-3.5 h-3.5 group-hover:-translate-y-0.5 transition-transform" />
          <span className="leading-none mt-0.5">BACK TO TOP</span>
        </button>
      )}

      {/* Floating Chat Button matching Screenshot 4, 8, 9 bottom right */}
      <button
        onClick={onOpenLiveChat}
        className="w-13 h-13 rounded-full bg-blue-600 hover:bg-blue-700 text-white flex items-center justify-center shadow-2xl shadow-blue-600/40 transition-transform active:scale-95 hover:scale-105 relative group border-2 border-white ring-4 ring-blue-600/20"
        aria-label="Open 24/7 Live Support Chat"
      >
        <span className="w-3 h-3 rounded-full bg-emerald-400 absolute top-0 right-0 border-2 border-white" />
        <MessageSquare className="w-6 h-6 fill-current" />
      </button>
    </div>
  );
};
