import React, { useState } from 'react';
import {
  X,
  Send,
  MessageCircle,
  ShieldCheck,
  Zap,
  HelpCircle,
  CheckCircle2,
} from 'lucide-react';

interface LiveChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectPlan: (plan: string, price: number) => void;
}

interface Message {
  id: string;
  sender: 'engineer' | 'user';
  text: string;
  time: string;
}

export const LiveChatDrawer: React.FC<LiveChatDrawerProps> = ({
  isOpen,
  onClose,
  onSelectPlan,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'engineer',
      text: 'Hello! I am Anand from Gitysoft Tier-3 Support in Mumbai. How can I help you with your hosting, VPS, or migration today?',
      time: 'Just now',
    },
  ]);
  const [inputValue, setInputValue] = useState('');

  if (!isOpen) return null;

  const handleSend = () => {
    if (!inputValue.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: inputValue,
      time: 'Just now',
    };
    setMessages((prev) => [...prev, userMsg]);
    const query = inputValue.toLowerCase();
    setInputValue('');

    // Simulated instant reply from Gitysoft senior engineer
    setTimeout(() => {
      let reply =
        'Thank you for reaching out! All our cloud servers run on AMD EPYC processors and enterprise Gen4 NVMe with LiteSpeed Web Server in Mumbai.';
      if (query.includes('migrat') || query.includes('transfer')) {
        reply =
          'We offer 100% free white-glove migration with zero downtime! Once you select a plan, our team will transfer all cPanels, databases, and emails within 2 hours.';
      } else if (query.includes('price') || query.includes('plan') || query.includes('cost')) {
        reply =
          'Our most popular plan is the Business Hosting at ₹199.99/mo which includes a Free Domain (.in/.com), 10 Business Inboxes, and Free Wildcard SSL with same renewal price!';
      } else if (query.includes('upi') || query.includes('payment') || query.includes('gst')) {
        reply =
          'We accept all Indian UPI apps (GPay, PhonePe, Paytm, BHIM), RuPay, Visa, MasterCard, and NetBanking with instant automated activation and valid 18% GST invoices.';
      } else if (query.includes('speed') || query.includes('litespeed') || query.includes('nvme')) {
        reply =
          'Our NVMe arrays deliver 7,500 MB/s sequential read/write speed with LiteSpeed Cache, loading WordPress sites in under 0.4 seconds with sub-5ms Indian latency.';
      }

      const engMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'engineer',
        text: reply,
        time: 'Just now',
      };
      setMessages((prev) => [...prev, engMsg]);
    }, 600);
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full max-w-md bg-white shadow-2xl border-l border-slate-200 flex flex-col animate-in slide-in-from-right duration-200">
      {/* Drawer Header */}
      <div className="p-4 bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 text-white flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-blue-500/40 border-2 border-white/80 flex items-center justify-center font-bold text-sm">
              AE
            </div>
            <span className="w-3 h-3 rounded-full bg-emerald-400 border-2 border-slate-900 absolute bottom-0 right-0" />
          </div>
          <div>
            <div className="text-sm font-bold flex items-center gap-1.5">
              Anand E. <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-[11px] text-blue-200">Tier-3 Linux SysAdmin · Mumbai DC</div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Trust banner */}
      <div className="bg-emerald-50 border-b border-emerald-100 p-2.5 px-4 text-[11px] text-emerald-800 flex items-center justify-between font-semibold">
        <span className="flex items-center gap-1.5">
          <Zap className="w-3.5 h-3.5 text-emerald-600" /> Average response time &lt; 2 minutes
        </span>
        <span className="text-[10px] bg-emerald-200/60 px-1.5 py-0.5 rounded text-emerald-900">
          Real Engineers
        </span>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 text-xs">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`p-3 rounded-2xl max-w-[85%] leading-relaxed ${
                m.sender === 'user'
                  ? 'bg-blue-600 text-white rounded-br-none shadow-xs'
                  : 'bg-slate-100 text-slate-800 rounded-bl-none border border-slate-200'
              }`}
            >
              {m.text}
            </div>
            <span className="text-[10px] text-slate-400 mt-1 px-1">{m.time}</span>
          </div>
        ))}
      </div>

      {/* Quick Questions Pills */}
      <div className="p-2 border-t border-slate-100 bg-slate-50 flex gap-1.5 overflow-x-auto text-[11px]">
        <button
          onClick={() => {
            setInputValue('Can you help migrate my cPanel from another host?');
          }}
          className="px-2.5 py-1 rounded-full bg-white border border-slate-200 hover:border-blue-400 text-slate-700 whitespace-nowrap shrink-0"
        >
          Free Migration?
        </button>
        <button
          onClick={() => {
            setInputValue('Which plan is best for WordPress WooCommerce?');
          }}
          className="px-2.5 py-1 rounded-full bg-white border border-slate-200 hover:border-blue-400 text-slate-700 whitespace-nowrap shrink-0"
        >
          WordPress Plan?
        </button>
        <button
          onClick={() => {
            setInputValue('Do you support UPI and Indian payment gateways?');
          }}
          className="px-2.5 py-1 rounded-full bg-white border border-slate-200 hover:border-blue-400 text-slate-700 whitespace-nowrap shrink-0"
        >
          UPI Checkout?
        </button>
      </div>

      {/* Input box */}
      <div className="p-3 bg-white border-t border-slate-200 flex items-center gap-2">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask a technical or billing question..."
          className="flex-1 px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-300 rounded-xl outline-hidden focus:border-blue-500 focus:bg-white transition-colors"
        />
        <button
          onClick={handleSend}
          className="p-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white transition-colors"
          aria-label="Send message"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
