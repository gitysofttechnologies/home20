import React from 'react';
import { Server, Phone, Mail, MapPin, ShieldCheck, Zap, Globe, Heart } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 text-slate-400 text-xs border-t border-slate-800">
      {/* Upper Footer: Highlights */}
      <div className="border-b border-slate-900 py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-900/50 text-blue-400 flex items-center justify-center shrink-0 border border-blue-800">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-white text-sm">Gen4 NVMe Speeds</div>
              <div className="text-[11px] text-slate-500">Up to 7,500 MB/s read/write</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-900/50 text-emerald-400 flex items-center justify-center shrink-0 border border-emerald-800">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-white text-sm">Tier-4 Certified SLA</div>
              <div className="text-[11px] text-slate-500">99.99% uptime guaranteed</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-900/50 text-purple-400 flex items-center justify-center shrink-0 border border-purple-800">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <div className="font-bold text-white text-sm">Low-Latency Indian Edge</div>
              <div className="text-[11px] text-slate-500">Sub-5ms peering with NIXI &amp; Jio</div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-900/50 text-amber-400 flex items-center justify-center shrink-0 border border-amber-800">
              <span className="font-black text-sm text-amber-400">100</span>
            </div>
            <div>
              <div className="font-bold text-white text-sm">GTmetrix 100/100</div>
              <div className="text-[11px] text-slate-500">Grade A performance score</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <a href="/" className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-md">
                <Server className="w-4 h-4" />
              </div>
              <span className="text-xl font-extrabold text-white tracking-tight">
                Gitysoft<span className="text-blue-500">.</span>
              </span>
            </a>

            <p className="text-xs text-slate-400 leading-relaxed max-w-sm">
              India&apos;s leading high-performance cloud hosting, bare metal infrastructure, and custom software
              engineering provider. Built on Tier-4 Indian datacenters with automated provisioning.
            </p>

            <div className="space-y-2 text-xs pt-2">
              <div className="flex items-center gap-2 text-slate-300">
                <MapPin className="w-4 h-4 text-blue-500 shrink-0" />
                <span>Tier-4 Datacenter Facility, Equinix MB1, Chandivali, Mumbai 400072, India</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Phone className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>+91 800-GITYSOFT / +91 (22) 6676-XXXX (24/7 Hotline)</span>
              </div>
              <div className="flex items-center gap-2 text-slate-300">
                <Mail className="w-4 h-4 text-purple-500 shrink-0" />
                <span>info@gitysoft.com / support@gitysoft.com</span>
              </div>
            </div>
          </div>

          {/* Hosting Solutions */}
          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-4">Hosting &amp; Cloud</h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <a href="#hosting-plans" className="hover:text-white transition-colors">
                  Turbo NVMe Web Hosting
                </a>
              </li>
              <li>
                <a href="#hosting-plans" className="hover:text-white transition-colors">
                  WordPress LiteSpeed Hosting
                </a>
              </li>
              <li>
                <a href="#cloud-vps" className="hover:text-white transition-colors">
                  AMD EPYC Cloud VPS
                </a>
              </li>
              <li>
                <a href="#bare-metal" className="hover:text-white transition-colors">
                  Dedicated Bare Metal
                </a>
              </li>
              <li>
                <a href="#hosting-plans" className="hover:text-white transition-colors">
                  cPanel Reseller Hosting
                </a>
              </li>
              <li>
                <a href="#architecture" className="hover:text-white transition-colors">
                  Titan Business Email
                </a>
              </li>
            </ul>
          </div>

          {/* Software & Growth */}
          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-4">Software &amp; Digital</h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <a href="#digital-services" className="hover:text-white transition-colors">
                  Custom ERP &amp; CRM Platforms
                </a>
              </li>
              <li>
                <a href="#digital-services" className="hover:text-white transition-colors">
                  React &amp; Next.js Engineering
                </a>
              </li>
              <li>
                <a href="#digital-services" className="hover:text-white transition-colors">
                  Bulk SMS &amp; WhatsApp API
                </a>
              </li>
              <li>
                <a href="#digital-services" className="hover:text-white transition-colors">
                  Digital Marketing &amp; SEO
                </a>
              </li>
              <li>
                <a href="#digital-services" className="hover:text-white transition-colors">
                  Ecommerce Stores (Shopify/Woo)
                </a>
              </li>
              <li>
                <a href="#digital-services" className="hover:text-white transition-colors">
                  Domain Name Registration
                </a>
              </li>
            </ul>
          </div>

          {/* Company & Trust */}
          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-4">Trust &amp; Legal</h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <a href="#why-choose" className="hover:text-white transition-colors">
                  About Gitysoft
                </a>
              </li>
              <li>
                <a href="#global-datacenters" className="hover:text-white transition-colors">
                  Global Datacenters
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  99.99% Uptime SLA
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  Privacy Policy &amp; Terms
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  30-Day Money-Back Guarantee
                </a>
              </li>
              <li>
                <a href="#faq" className="hover:text-white transition-colors">
                  Security &amp; Compliance (ISO/HIPAA)
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Payment & Security Trust Badges */}
        <div className="mt-12 pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
            <span className="font-semibold text-slate-300">Accepted Payment Methods:</span>
            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 font-mono">
              UPI (GPay / PhonePe / Paytm)
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 font-mono">
              RuPay
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 font-mono">
              Visa / MasterCard
            </span>
            <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300 font-mono">
              NetBanking
            </span>
          </div>

          <div className="text-[11px] text-slate-500 flex items-center gap-1">
            <span>© 2026 Gitysoft Technologies Private Limited. All rights reserved.</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
