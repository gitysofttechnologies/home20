import React, { useState } from 'react';
import {
  Globe,
  Server,
  Zap,
  Shield,
  Activity,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  Radio,
  Cpu,
  MapPin,
} from 'lucide-react';

interface GlobalInfrastructureProps {
  onOpenCheckout: (planName: string, price: number) => void;
}

export const GlobalInfrastructure: React.FC<GlobalInfrastructureProps> = ({ onOpenCheckout }) => {
  const [selectedRegion, setSelectedRegion] = useState('Europe');
  const [activePillar, setActivePillar] = useState(3);

  const regionLocations: Record<string, { city: string; country: string; ping: string; type: string }> = {
    Americas: { city: 'Ashburn, Virginia', country: 'United States', ping: '142.0 ms', type: 'Anycast DNS & Storage' },
    Europe: { city: 'Frankfurt', country: 'Germany', ping: '98.2 ms', type: 'Active Edge Node' },
    Asia: { city: 'Mumbai (MB1)', country: 'India', ping: '2.1 ms', type: 'Primary Tier-4 DC' },
    'Middle East': { city: 'Dubai', country: 'UAE', ping: '38.4 ms', type: 'Edge Routing Point' },
    Australia: { city: 'Sydney', country: 'Australia', ping: '168.0 ms', type: 'Edge Acceleration Node' },
  };

  const currentLocation = regionLocations[selectedRegion] || regionLocations['Europe'];

  const pillars = [
    { num: 1, name: 'High Performance', icon: Zap },
    { num: 2, name: 'Enterprise Security', icon: Shield },
    { num: 3, name: 'Global Infrastructure', icon: Globe },
    { num: 4, name: 'Developer Friendly', icon: Cpu },
    { num: 5, name: 'Scalable Resources', icon: Server },
  ];

  return (
    <section id="global-datacenters" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section 1: Closer to You, Faster for Everyone (Screenshot 3) */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div className="max-w-2xl">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 leading-tight">
              Closer to You, <br className="hidden sm:inline" />
              Faster for Everyone
            </h2>
            <p className="mt-3 text-sm sm:text-base text-slate-600">
              Our strategically located data centers ensure low latency, high performance, and unmatched reliability.
            </p>
          </div>

          <button
            onClick={() => onOpenCheckout('Global Anycast Cloud Node', 1499)}
            className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs tracking-wide shadow-md transition-all shrink-0 flex items-center gap-2 self-start md:self-auto"
          >
            View All Locations <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Region Tabs (Americas, Europe, Asia, Middle East, Australia) */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8">
          {['Americas', 'Europe', 'Asia', 'Middle East', 'Australia'].map((reg) => (
            <button
              key={reg}
              onClick={() => setSelectedRegion(reg)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
                selectedRegion === reg
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {reg}
            </button>
          ))}
        </div>

        {/* Map & Global Edge Visual (Screenshot 3) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-20">
          {/* Left: 50+ Global Locations with interactive points */}
          <div className="lg:col-span-8 bg-blue-50/50 rounded-3xl p-6 sm:p-8 border border-blue-100 relative overflow-hidden flex flex-col justify-between min-h-[340px]">
            {/* SVG Globe Network Background */}
            <div className="absolute inset-0 flex items-center justify-center opacity-30 pointer-events-none">
              <svg className="w-full h-full" viewBox="0 0 600 300" fill="none">
                <circle cx="150" cy="140" r="80" stroke="#3b82f6" strokeWidth="1" strokeDasharray="4 4" />
                <circle cx="350" cy="120" r="120" stroke="#3b82f6" strokeWidth="1" strokeDasharray="4 4" />
                <circle cx="500" cy="180" r="60" stroke="#3b82f6" strokeWidth="1" strokeDasharray="4 4" />
                <path d="M 150 140 Q 250 80 350 120 T 500 180" stroke="#2563eb" strokeWidth="2" />
                {/* Node dots */}
                <circle cx="150" cy="140" r="6" fill="#2563eb" className="animate-ping" />
                <circle cx="150" cy="140" r="4" fill="#1d4ed8" />
                <circle cx="280" cy="100" r="4" fill="#3b82f6" />
                <circle cx="350" cy="120" r="6" fill="#10b981" />
                <circle cx="420" cy="140" r="4" fill="#3b82f6" />
                <circle cx="500" cy="180" r="5" fill="#3b82f6" />
              </svg>
            </div>

            {/* Floating Location Card */}
            <div className="bg-white/95 backdrop-blur-md rounded-2xl p-5 border border-slate-200 shadow-xl max-w-sm relative z-10">
              <div className="text-2xl font-black text-slate-900 font-mono">50+</div>
              <div className="text-xs font-bold text-blue-600 mb-1">Global Locations</div>
              <p className="text-[11px] text-slate-600 mb-3 leading-relaxed">
                Delivering a faster, more reliable internet experience — no matter where you are.
              </p>

              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-rose-500" />
                  <span className="font-bold text-slate-900">
                    {currentLocation.city}, {currentLocation.country}
                  </span>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                  {currentLocation.type}
                </span>
              </div>
            </div>

            {/* Bottom badges */}
            <div className="flex flex-wrap items-center gap-4 text-xs font-semibold text-slate-700 relative z-10 pt-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600" /> 100% NVMe Edge
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" /> Tier IV Certified
              </span>
              <span className="flex items-center gap-1.5 font-mono text-blue-600 ml-auto">
                Ping: {currentLocation.ping}
              </span>
            </div>
          </div>

          {/* Right: Growing Together Across the Globe (Screenshot 3) */}
          <div className="lg:col-span-4 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xl flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-6 border border-blue-100">
                <Globe className="w-6 h-6" />
              </div>

              <h3 className="text-2xl font-black text-slate-900 leading-snug mb-3">
                Growing Together Across the Globe
              </h3>

              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed mb-6">
                Join millions of developers, agencies, and businesses scaling with Gitysoft high-availability cloud
                infrastructure.
              </p>
            </div>

            <button
              onClick={() => onOpenCheckout('Global Enterprise Cloud Cluster', 4999)}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-xs tracking-wide shadow-md transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              Join Thousands Today <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Section 2: Everything You Need. All in One Place. (Screenshot 4) */}
        <div className="pt-10 border-t border-slate-200">
          <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-10">
            <div>
              <span className="inline-block px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider bg-blue-50 text-blue-700 border border-blue-200 mb-3">
                ✦ WHY CHOOSE GITYSOFT
              </span>
              <h3 className="text-3xl sm:text-4xl font-black tracking-tight text-slate-900">
                Everything You Need. <br /> All in One Place.
              </h3>
              <p className="mt-3 text-xs sm:text-sm text-slate-600 max-w-xl">
                High-density, carrier-neutral facilities located in Mumbai, Singapore, Frankfurt, and US East with
                redundant power grids and dual 10Gbps uplinks.
              </p>
            </div>

            {/* 5 Pillars Quick Selector Bar (Screenshot 4) */}
            <div className="flex items-center gap-2 overflow-x-auto pb-2">
              {pillars.map((pil) => {
                const Icon = pil.icon;
                const isSelected = activePillar === pil.num;
                return (
                  <button
                    key={pil.num}
                    onClick={() => setActivePillar(pil.num)}
                    className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1 shrink-0 min-w-[90px] ${
                      isSelected
                        ? 'border-slate-900 bg-white ring-2 ring-slate-900 shadow-md'
                        : 'border-slate-200 bg-slate-50 hover:bg-white text-slate-600'
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isSelected ? 'text-blue-600' : 'text-slate-500'}`} />
                    <span className="text-[10px] font-bold leading-tight">{pil.name}</span>
                    {isSelected && (
                      <span className="text-[9px] font-extrabold uppercase bg-blue-100 text-blue-800 px-1 rounded mt-0.5">
                        ACTIVE
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Detailed Pillar 03 Datacenter Network Box (Screenshot 4) */}
          <div className="bg-slate-50/70 rounded-3xl p-6 sm:p-8 lg:p-10 border border-slate-200 shadow-xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 text-xs text-slate-500 mb-6">
              <span className="font-bold uppercase tracking-wider text-blue-700">
                PILLAR 03 · TIER-4 CERTIFIED DATACENTERS
              </span>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-mono">Pillar 03 of 05</span>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setActivePillar(Math.max(1, activePillar - 1))}
                    className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100"
                  >
                    <ChevronLeft className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => setActivePillar(Math.min(5, activePillar + 1))}
                    className="p-1 rounded bg-white border border-slate-200 hover:bg-slate-100"
                  >
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
              {/* Left Column: Specs & Guarantees */}
              <div className="lg:col-span-7 space-y-6">
                <div>
                  <span className="text-xs font-mono font-bold text-blue-600 uppercase">
                    ✦ PILLAR 03 · GLOBAL INFRASTRUCTURE
                  </span>
                  <h4 className="text-2xl sm:text-3xl font-black text-slate-900 mt-1 leading-snug">
                    Global Tier-4 Datacenter Network & Low Latency Edge
                  </h4>
                  <p className="text-xs sm:text-sm text-slate-600 mt-2">
                    High-density, carrier-neutral facilities located in Mumbai, Singapore, Frankfurt, and US East with
                    redundant power grids and dual 10Gbps uplinks.
                  </p>
                </div>

                {/* 4 Metric Boxes */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Uptime SLA</div>
                    <div className="text-lg font-black text-slate-900 font-mono mt-0.5">99.99%</div>
                    <div className="text-[9px] text-slate-500">Financially Guaranteed</div>
                  </div>

                  <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Primary Node</div>
                    <div className="text-sm font-black text-slate-900 font-mono mt-0.5">Tier-4 Mumbai</div>
                    <div className="text-[9px] text-slate-500">N+1 Diesel UPS</div>
                  </div>

                  <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Network Uplinks</div>
                    <div className="text-sm font-black text-slate-900 font-mono mt-0.5">Dual 10 Gbps</div>
                    <div className="text-[9px] text-slate-500">Carrier-Neutral BGP</div>
                  </div>

                  <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-xs">
                    <div className="text-[10px] text-slate-400 uppercase font-semibold">Global POPs</div>
                    <div className="text-sm font-black text-slate-900 font-mono mt-0.5">4 Datacenters</div>
                    <div className="text-[9px] text-slate-500">Anycast DNS Network</div>
                  </div>
                </div>

                {/* Checkmarks */}
                <div className="space-y-2.5 text-xs text-slate-700">
                  {[
                    'Direct peering with NIXI, Airtel, Jio, and Tata Communications',
                    'Fully redundant N+1 power generators with 72-hour on-site fuel reserve',
                    'Biometric two-factor escorted access with 24/7 CCTV physical security',
                    '100% renewable energy matching with zero carbon footprint footprint',
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right Column: Global Node Telemetry (Screenshot 4) */}
              <div className="lg:col-span-5 bg-slate-950 rounded-3xl p-5 sm:p-6 border border-slate-800 text-white font-mono shadow-2xl">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs">
                  <span className="text-blue-400 font-bold flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-blue-500" /> GLOBAL NODE TELEMETRY
                  </span>
                  <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                    99.99% SLA
                  </span>
                </div>

                <div className="divide-y divide-slate-800/80 my-4 text-xs">
                  <div className="py-2.5 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="font-semibold text-slate-200">Mumbai Tier-4</span>
                    </div>
                    <span className="text-emerald-400 font-bold">2.1 ms (PRIMARY)</span>
                  </div>

                  <div className="py-2.5 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-blue-400" />
                      <span className="font-semibold text-slate-300">Singapore SG-1</span>
                    </div>
                    <span className="text-blue-400 font-bold">24.5 ms</span>
                  </div>

                  <div className="py-2.5 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-indigo-400" />
                      <span className="font-semibold text-slate-300">Frankfurt FRA-02</span>
                    </div>
                    <span className="text-indigo-400 font-bold">98.2 ms</span>
                  </div>

                  <div className="py-2.5 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-purple-400" />
                      <span className="font-semibold text-slate-300">US East (Virginia)</span>
                    </div>
                    <span className="text-purple-400 font-bold">142.0 ms</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-800/80 text-[10px] text-slate-500 flex items-center justify-between">
                  <span>Routing: BGP Anycast</span>
                  <span className="text-emerald-400">All Nodes Nominal</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
