import React, { useState } from 'react';
import { DEDICATED_SERVERS } from '../data/hostingData';
import { Currency } from '../types';
import { formatCurrency } from '../utils/pricing';
import {
  Server,
  Cpu,
  Activity,
  HardDrive,
  Radio,
  Check,
  ShieldCheck,
  Zap,
  Flame,
  ArrowRight,
  Terminal,
} from 'lucide-react';

interface DedicatedBareMetalProps {
  currency: Currency;
  onOpenCheckout: (planName: string, price: number) => void;
}

export const DedicatedBareMetal: React.FC<DedicatedBareMetalProps> = ({ currency, onOpenCheckout }) => {
  const [selectedServerIndex, setSelectedServerIndex] = useState(0);
  const server = DEDICATED_SERVERS[selectedServerIndex];

  return (
    <section id="bare-metal" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 mb-12">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-bold uppercase tracking-wider mb-3">
              <Server className="w-3.5 h-3.5 text-blue-600" /> 100% Dedicated Hardware · Zero Virtualization Overhead
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 leading-tight">
              Enterprise Dedicated Servers & Bare Metal
            </h2>
            <p className="mt-3 text-base text-slate-600">
              Raw physical compute power powered by AMD EPYC & Intel Xeon with 10 Gbps unmetered uplink, IPMI root
              access, and instant automated provisioning.
            </p>
          </div>

          {/* 3 Right Header Badges */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <span className="px-3 py-1.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500" /> 100% Hardware SLA
            </span>
            <span className="px-3 py-1.5 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-blue-600" /> 10 Gbps Port Ready
            </span>
            <span className="px-3 py-1.5 rounded-full text-xs font-bold bg-purple-50 text-purple-700 border border-purple-200 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-purple-600" /> 3.2 Tbps DDoS Shield
            </span>
          </div>
        </div>

        {/* 2-Column Bare Metal Grid matching Screenshot 11 */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Column: Dedicated Server Card */}
          <div className="lg:col-span-8 bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-8 shadow-xl flex flex-col justify-between">
            <div>
              {/* Category, Node & Status bar */}
              <div className="flex flex-wrap items-center justify-between gap-2 pb-4 border-b border-slate-100 text-xs text-slate-500">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-md bg-slate-900 text-white font-bold text-[11px]">
                    {server.category}
                  </span>
                  <span className="font-semibold text-slate-600">Node: {server.node}</span>
                </div>
                <div className="flex items-center gap-1.5 text-emerald-600 font-bold text-[11px]">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" /> Bare Metal Provisioning
                </div>
              </div>

              {/* Title & Pricing */}
              <div className="flex flex-wrap items-center justify-between gap-4 my-6">
                <div>
                  <div className="flex items-center gap-2.5">
                    <h3 className="text-2xl sm:text-3xl font-black text-slate-900">{server.model}</h3>
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      {server.deployTime}
                    </span>
                  </div>
                  <div className="text-xs font-semibold text-blue-600 mt-1">{server.cpuModel}</div>
                </div>

                <div className="text-right">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl sm:text-4xl font-black text-slate-950 font-mono">
                      {formatCurrency(server.monthlyPrice, currency)}
                    </span>
                    <span className="text-xs text-slate-500 font-semibold">/month</span>
                  </div>
                  <div className="text-[11px] text-slate-500 font-medium">Zero Setup Fees · Month-to-Month</div>
                </div>
              </div>

              {/* 4 Hardware Specs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
                <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
                  <div className="flex items-center gap-1.5 text-blue-600 text-xs font-bold uppercase mb-1">
                    <Cpu className="w-3.5 h-3.5" /> Processing
                  </div>
                  <div className="text-xs font-extrabold text-slate-900 font-mono leading-snug">
                    {server.coresThreads}
                  </div>
                </div>

                <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
                  <div className="flex items-center gap-1.5 text-purple-600 text-xs font-bold uppercase mb-1">
                    <Activity className="w-3.5 h-3.5" /> Memory
                  </div>
                  <div className="text-xs font-extrabold text-slate-900 font-mono leading-snug">{server.ram}</div>
                </div>

                <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
                  <div className="flex items-center gap-1.5 text-emerald-600 text-xs font-bold uppercase mb-1">
                    <HardDrive className="w-3.5 h-3.5" /> NVMe Storage
                  </div>
                  <div className="text-xs font-extrabold text-slate-900 font-mono leading-snug">
                    {server.storage}
                  </div>
                </div>

                <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80">
                  <div className="flex items-center gap-1.5 text-indigo-600 text-xs font-bold uppercase mb-1">
                    <Radio className="w-3.5 h-3.5" /> Network
                  </div>
                  <div className="text-xs font-extrabold text-slate-900 font-mono leading-snug">
                    {server.network}
                  </div>
                </div>
              </div>

              {/* Features List */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 text-xs text-slate-700">
                {server.features.map((feat, fIdx) => (
                  <div key={fIdx} className="flex items-center gap-2">
                    <div className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3" />
                    </div>
                    <span className="font-medium">{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
              <span className="text-xs text-slate-500 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500" /> Instant Hardware Provisioning · OS: Ubuntu,
                Windows, Proxmox, ESXi
              </span>

              <button
                onClick={() => onOpenCheckout(server.model, server.monthlyPrice)}
                className="w-full sm:w-auto px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-600/20 transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                Deploy Bare Metal <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Right Column: Live Hardware IPMI (Screenshot 11) */}
          <div className="lg:col-span-4 bg-slate-50/80 rounded-3xl border border-slate-200 p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-slate-200 text-xs">
                <span className="font-mono text-slate-700 font-bold flex items-center gap-1.5">
                  <Terminal className="w-3.5 h-3.5 text-blue-600" /> LIVE HARDWARE IPMI
                </span>
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                  REAL-TIME
                </span>
              </div>

              {/* Telemetry Sensor Card */}
              <div className="bg-white rounded-2xl p-4 my-4 border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                  <span>Sensor Telemetry</span>
                  <span className="font-mono text-slate-700 font-bold">Node MUM-BM-01</span>
                </div>
                <div className="text-[11px] text-slate-400">CPU Thermal Status</div>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-3xl font-black text-slate-900 font-mono">36.8°C</span>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    OPTIMAL
                  </span>
                </div>
                <div className="text-[10px] text-slate-500 mt-1">Liquid Loop Active</div>
                <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2">
                  <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: '38%' }} />
                </div>
              </div>

              {/* Specs Grid */}
              <div className="grid grid-cols-2 gap-2.5 text-xs">
                <div className="bg-white p-3 rounded-xl border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase">Uplink Port</div>
                  <div className="font-bold text-slate-900 font-mono mt-0.5">10 Gbps SFP28</div>
                  <div className="text-[9px] text-emerald-600">Unmetered SLA</div>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase">KVM Over IP</div>
                  <div className="font-bold text-slate-900 font-mono mt-0.5">HTML5 Virtual</div>
                  <div className="text-[9px] text-blue-600">Out-of-Band</div>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase">DDoS Protection</div>
                  <div className="font-bold text-slate-900 font-mono mt-0.5">3.2 Tbps L3/L4/L7</div>
                  <div className="text-[9px] text-purple-600">Always Active</div>
                </div>

                <div className="bg-white p-3 rounded-xl border border-slate-200">
                  <div className="text-[10px] text-slate-400 uppercase">Hardware Swap</div>
                  <div className="font-bold text-slate-900 font-mono mt-0.5">&lt; 15 Minutes</div>
                  <div className="text-[9px] text-amber-600">On-site Spares</div>
                </div>
              </div>
            </div>

            {/* Bottom 1U SuperServer Card */}
            <div className="mt-4 p-3 bg-white rounded-xl border border-slate-200 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 bg-slate-100 rounded text-[10px] font-bold font-mono text-slate-700">
                  1U
                </span>
                <div>
                  <div className="font-bold text-slate-900 text-xs">Supermicro SuperServer</div>
                  <div className="text-[10px] text-slate-500">Dual Redundant PSUs</div>
                </div>
              </div>
              <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                ONLINE
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
