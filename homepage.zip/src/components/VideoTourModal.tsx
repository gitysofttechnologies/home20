import React from 'react';
import { X, Server, ShieldCheck, Zap, Radio } from 'lucide-react';

interface VideoTourModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VideoTourModal: React.FC<VideoTourModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-slate-900 rounded-3xl max-w-3xl w-full border border-slate-800 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 flex items-center justify-between border-b border-slate-800 text-white">
          <div className="flex items-center gap-2">
            <Server className="w-5 h-5 text-blue-400" />
            <div>
              <h3 className="text-sm sm:text-base font-bold">Inside Gitysoft Tier-4 Datacenter</h3>
              <p className="text-[11px] text-slate-400">Equinix MB1 · N+1 Generator Grids · Mumbai, India</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 flex items-center justify-center text-slate-300 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Video / Virtual Simulation Surface */}
        <div className="relative aspect-video bg-black overflow-hidden flex items-center justify-center">
          <img
            src="/src/assets/images/datacenter_server_room_1793935095545.jpg"
            alt="Gitysoft Data Center Tour"
            className="w-full h-full object-cover opacity-80"
          />

          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/60 p-6 flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-white">
              <span className="bg-red-600 px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 animate-pulse">
                <span className="w-2 h-2 rounded-full bg-white" /> LIVE CAM 04 - CORRIDOR C
              </span>
              <span className="font-mono text-emerald-400 bg-black/60 px-2 py-1 rounded">
                Telemetry: 22.4°C / 45% Humidity
              </span>
            </div>

            <div className="text-center space-y-2">
              <div className="inline-block p-4 rounded-full bg-blue-600/90 text-white shadow-xl backdrop-blur-xs">
                <Server className="w-8 h-8 animate-bounce" />
              </div>
              <h4 className="text-lg font-bold text-white">High-Density Rack Architecture</h4>
              <p className="text-xs text-slate-300 max-w-md mx-auto">
                Featuring redundant 1600W Titanium hot-swap PSUs, dual 10 Gbps unmetered uplink cables, and isolated LVE
                sandboxes.
              </p>
            </div>

            <div className="grid grid-cols-3 gap-2 text-center text-[11px] text-slate-300 font-mono bg-black/60 p-2.5 rounded-xl backdrop-blur-xs">
              <div>PUE Rating: 1.15</div>
              <div>Security: Biometric + CCTV</div>
              <div>Power: Dual Substation</div>
            </div>
          </div>
        </div>

        <div className="p-4 bg-slate-950 flex items-center justify-between text-xs text-slate-400 border-t border-slate-800">
          <span>Enterprise Physical Security &amp; ISO 27001 Certified</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs"
          >
            Close Tour
          </button>
        </div>
      </div>
    </div>
  );
};
