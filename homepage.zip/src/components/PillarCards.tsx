import React from 'react';
import { Currency } from '../types';
import { formatCurrency } from '../utils/pricing';
import {
  Check,
  Server,
  Mail,
  ShoppingCart,
  Terminal,
  ShieldCheck,
  Zap,
  ArrowRight,
  Smartphone,
  CreditCard,
} from 'lucide-react';

interface PillarCardsProps {
  currency: Currency;
  onOpenCheckout: (planName: string, price: number) => void;
}

export const PillarCards: React.FC<PillarCardsProps> = ({ currency, onOpenCheckout }) => {
  return (
    <section className="py-14 bg-slate-50/60 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {/* Card 1: Cloud VPS (Dark theme) */}
          <div className="rounded-3xl bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-950 border border-slate-800 p-6 sm:p-7 text-white shadow-xl flex flex-col justify-between relative overflow-hidden group hover:border-indigo-500/50 transition-all duration-300">
            <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="px-3 py-1 rounded-full text-xs font-bold tracking-wider uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Cloud VPS
                </span>
                <div className="flex items-center gap-1">
                  <span className="w-4 h-1.5 rounded-full bg-indigo-400" />
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />
                </div>
              </div>

              <h3 className="text-xl sm:text-2xl font-bold tracking-tight mb-4 text-white leading-snug">
                High-Performance Cloud VPS for Growing Apps
              </h3>

              <div className="grid grid-cols-1 gap-2.5 mb-6 text-sm text-slate-300">
                {[
                  'Dedicated vCPU & RAM',
                  'NVMe Cloud Storage',
                  'Full Root SSH Access',
                  'Instant Auto Provisioning',
                  'DDoS Protection Included',
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2.5">
                    <div className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3" />
                    </div>
                    <span>{item}</span>
                  </div>
                ))}
              </div>

              {/* Server visual graphic */}
              <div className="p-3.5 rounded-2xl bg-slate-950/80 border border-slate-800 mb-6 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-indigo-900/60 flex items-center justify-center text-indigo-400">
                    <Server className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-mono text-emerald-400 flex items-center gap-1 text-[11px]">
                      <Terminal className="w-3 h-3" /> Root SSH
                    </span>
                    <span className="text-[10px] text-slate-400">100% NVMe Gen4 Array</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center gap-1 text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded-full">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> DDoS Guard
                  </span>
                  <div className="text-[10px] text-indigo-300 font-mono mt-0.5">✦ 10 Gbps Port</div>
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between gap-3 border-t border-slate-800/80">
              <button
                onClick={() => onOpenCheckout('Cloud VPS Starter', 449)}
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs tracking-wide shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
              >
                Explore VPS Plans <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <div className="text-right">
                <span className="text-[10px] uppercase text-slate-400 block font-semibold">Starting At</span>
                <span className="text-sm font-extrabold text-indigo-300 font-mono">
                  {formatCurrency(449, currency)}/mo
                </span>
              </div>
            </div>
          </div>

          {/* Card 2: Titan Business Email (Cyan theme) */}
          <div className="rounded-3xl bg-cyan-50/40 border border-cyan-200/80 p-6 sm:p-7 text-slate-900 shadow-lg flex flex-col justify-between relative overflow-hidden group hover:border-cyan-400 transition-all duration-300">
            <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-200/20 rounded-full blur-2xl pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="px-3 py-1 rounded-full text-xs font-bold tracking-wider uppercase bg-cyan-100 text-cyan-800 border border-cyan-300">
                  Titan Business Email
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-bold tracking-tight mb-4 text-slate-900 leading-snug">
                Professional Titan Email for Growing Businesses
              </h3>

              <div className="grid grid-cols-1 gap-2.5 mb-6 text-sm text-slate-700">
                {[
                  '50 GB Storage per Inbox',
                  'AI-Powered Spam Shield',
                  'Calendar & Contact Sync',
                  'Custom Domain Addressing',
                  'Guaranteed Inbox Delivery',
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2.5">
                    <div className="w-4 h-4 rounded-full bg-cyan-100 text-cyan-700 flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3" />
                    </div>
                    <span>{item}</span>
                  </div>
                ))}
              </div>

              {/* Graphic container */}
              <div className="p-3.5 rounded-2xl bg-white border border-cyan-200 mb-6 flex items-center justify-between text-xs shadow-xs">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-cyan-600 text-white flex items-center justify-center">
                    <Mail className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900 block text-xs">you@yourbrand.com</span>
                    <span className="text-[10px] text-emerald-600 font-medium flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> Anti-Spam Active
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center gap-1 text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-full font-mono">
                    TLS 1.3
                  </span>
                  <div className="text-[10px] text-cyan-700 font-semibold mt-0.5">✦ 50 GB NVMe</div>
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between gap-3 border-t border-cyan-200/80">
              <button
                onClick={() => onOpenCheckout('Titan Business Email', 59)}
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-xs tracking-wide shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
              >
                Get Business Email <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <div className="text-right">
                <span className="text-[10px] uppercase text-slate-500 block font-semibold">Starting At</span>
                <span className="text-sm font-extrabold text-cyan-800 font-mono">
                  {formatCurrency(59, currency)}/mo
                </span>
              </div>
            </div>
          </div>

          {/* Card 3: Ecommerce Stores (Gold/Amber theme) */}
          <div className="rounded-3xl bg-amber-50/40 border border-amber-200/80 p-6 sm:p-7 text-slate-900 shadow-lg flex flex-col justify-between relative overflow-hidden group hover:border-amber-400 transition-all duration-300">
            <div className="absolute top-0 right-0 w-48 h-48 bg-amber-200/20 rounded-full blur-2xl pointer-events-none" />

            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="px-3 py-1 rounded-full text-xs font-bold tracking-wider uppercase bg-amber-100 text-amber-900 border border-amber-300">
                  Ecommerce Stores
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-bold tracking-tight mb-4 text-slate-900 leading-snug">
                High-Converting Online Ecommerce Stores
              </h3>

              <div className="grid grid-cols-1 gap-2.5 mb-6 text-sm text-slate-700">
                {[
                  'WooCommerce & Shopify',
                  'Razorpay & UPI Payments',
                  'Automated Order Tracking',
                  'Inventory & Stock Sync',
                  'Abandoned Cart Recovery',
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2.5">
                    <div className="w-4 h-4 rounded-full bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                      <Check className="w-3 h-3" />
                    </div>
                    <span>{item}</span>
                  </div>
                ))}
              </div>

              {/* Checkout mockup */}
              <div className="p-3.5 rounded-2xl bg-white border border-amber-200 mb-6 flex items-center justify-between text-xs shadow-xs">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center">
                    <ShoppingCart className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-semibold text-slate-900 block text-xs">UPI & Cards Checkout</span>
                    <span className="text-[10px] text-emerald-600 font-medium flex items-center gap-1">
                      <ShieldCheck className="w-3 h-3" /> Zero Glitch Gateway
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center gap-1 text-[10px] bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full font-semibold">
                    Fast Checkout
                  </span>
                  <div className="text-[10px] text-amber-800 font-semibold mt-0.5">✦ Responsive Shop</div>
                </div>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between gap-3 border-t border-amber-200/80">
              <button
                onClick={() => onOpenCheckout('Custom Ecommerce Store', 7999)}
                className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-xs tracking-wide shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5"
              >
                Build Ecommerce Shop <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <div className="text-right">
                <span className="text-[10px] uppercase text-slate-500 block font-semibold">Starting At</span>
                <span className="text-sm font-extrabold text-amber-900 font-mono">
                  {formatCurrency(7999, currency)}
                  <span className="text-[10px] block font-normal text-slate-500">/one-time</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
