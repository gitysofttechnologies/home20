import React, { useState } from 'react';
import { FAQS } from '../data/hostingData';
import {
  HelpCircle,
  ChevronDown,
  ChevronUp,
  MessageCircle,
  Mail,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

interface FaqSectionProps {
  onOpenLiveChat: () => void;
  onOpenEmailSupport: () => void;
}

export const FaqSection: React.FC<FaqSectionProps> = ({ onOpenLiveChat, onOpenEmailSupport }) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number>(1); // Index 1 open by default matching Screenshot 7

  const toggleFaq = (idx: number) => {
    setOpenFaqIndex(openFaqIndex === idx ? -1 : idx);
  };

  return (
    <section id="faq" className="py-20 bg-slate-50/50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-bold uppercase tracking-wider mb-2">
              <HelpCircle className="w-3.5 h-3.5 text-blue-600" /> FAQ
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 leading-tight">
              Frequently Asked Questions
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-slate-600">
              Everything you need to know about Gitysoft Cloud
            </p>
          </div>

          <button
            onClick={onOpenLiveChat}
            className="px-5 py-2.5 rounded-xl bg-white border border-slate-300 hover:border-slate-400 text-slate-800 text-xs font-bold shadow-xs hover:shadow-sm transition-all self-start sm:self-auto flex items-center gap-2"
          >
            Ask a question <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* 2-Column FAQ Layout matching Screenshot 7 */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: 7 FAQ Items */}
          <div className="lg:col-span-8 space-y-3">
            {FAQS.map((faq, idx) => {
              const isOpen = openFaqIndex === idx;
              return (
                <div
                  key={idx}
                  className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                    isOpen ? 'border-blue-400 bg-white shadow-md' : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <button
                    onClick={() => toggleFaq(idx)}
                    className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4"
                  >
                    <span
                      className={`text-xs sm:text-sm font-extrabold ${
                        isOpen ? 'text-blue-600' : 'text-slate-900'
                      }`}
                    >
                      {faq.question}
                    </span>
                    <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 shrink-0">
                      {isOpen ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-5 pb-5 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-100 animate-in fade-in duration-150">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Right Column: Still Have Questions? Card (Screenshot 7) */}
          <div className="lg:col-span-4 bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-xl space-y-6">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center border border-blue-100">
              <MessageCircle className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-xl font-extrabold text-slate-900 leading-snug">Still have questions?</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Can&apos;t find the answer you&apos;re looking for? Our support team is available 24/7 — real engineers, not
                bots.
              </p>
            </div>

            <div className="space-y-2.5">
              <button
                onClick={onOpenLiveChat}
                className="w-full py-3 px-4 rounded-xl bg-blue-700 hover:bg-blue-800 text-white font-bold text-xs tracking-wide shadow-md shadow-blue-700/20 transition-all active:scale-95 flex items-center justify-center gap-2"
              >
                Chat with support <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <button
                onClick={onOpenEmailSupport}
                className="w-full py-3 px-4 rounded-xl bg-white border border-slate-200 hover:border-slate-300 text-slate-700 font-bold text-xs transition-colors flex items-center justify-center gap-2"
              >
                <Mail className="w-3.5 h-3.5" /> Email us
              </button>
            </div>

            {/* 4 Trust Metrics */}
            <div className="grid grid-cols-2 gap-3 pt-6 border-t border-slate-100 text-center">
              <div>
                <div className="text-lg font-black text-slate-900 font-mono">&lt; 5 min</div>
                <div className="text-[10px] text-slate-400 font-semibold uppercase mt-0.5">Response Time</div>
              </div>
              <div>
                <div className="text-lg font-black text-slate-900 font-mono">24/7</div>
                <div className="text-[10px] text-slate-400 font-semibold uppercase mt-0.5">Availability</div>
              </div>
              <div>
                <div className="text-lg font-black text-emerald-600 font-mono">98%</div>
                <div className="text-[10px] text-slate-400 font-semibold uppercase mt-0.5">Satisfaction</div>
              </div>
              <div>
                <div className="text-lg font-black text-blue-600 font-mono">Real</div>
                <div className="text-[10px] text-slate-400 font-semibold uppercase mt-0.5">Engineers</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
