import React, { useState } from 'react';
import {
  Globe,
  CreditCard,
  Layers,
  Rocket,
  CheckCircle2,
  Terminal,
  RotateCcw,
  ArrowRight,
  ShieldCheck,
  Zap,
} from 'lucide-react';

export const HowItWorksSteps: React.FC = () => {
  const [activeStep, setActiveStep] = useState(3);
  const [isRunning, setIsRunning] = useState(false);
  const [logIndex, setLogIndex] = useState(5);

  const logs = [
    { time: '[00:03.1]', text: 'Allocating isolated CloudLinux LVE CageFS sandbox...', status: 'INIT', color: 'text-slate-300' },
    { time: '[00:11.8]', text: 'Mounted 50GB Gen4 NVMe storage (I/O: 30MB/s limit removed)', status: '[OK]', color: 'text-emerald-400' },
    { time: '[00:24.2]', text: 'Configured LiteSpeed Enterprise Web Server with HTTP/3 QUIC', status: '[OK]', color: 'text-emerald-400' },
    { time: '[00:36.5]', text: "Issued Let's Encrypt 256-Bit SSL certificate wildcard", status: '[INSTALLED]', color: 'text-amber-300' },
    { time: '[00:44.9]', text: 'Provisioned MariaDB 10.6 database cluster with phpMyAdmin', status: '[READY]', color: 'text-purple-400' },
  ];

  const handleRerun = () => {
    setIsRunning(true);
    setLogIndex(0);
    const interval = setInterval(() => {
      setLogIndex((prev) => {
        if (prev >= logs.length - 1) {
          clearInterval(interval);
          setIsRunning(false);
          return logs.length;
        }
        return prev + 1;
      });
    }, 400);
  };

  const steps = [
    {
      num: '01',
      tag: 'DOMAIN',
      title: 'Find & Register Domain',
      sub: 'Live TLD Radar',
      time: '~45s',
      icon: Globe,
    },
    {
      num: '02',
      tag: 'PAYMENT',
      title: 'UPI & Secure Checkout',
      sub: '256-Bit Encrypted',
      time: '~30s',
      icon: CreditCard,
    },
    {
      num: '03',
      tag: 'CLOUD SPIN',
      title: '60s Auto Provisioning',
      sub: 'Mumbai DC Node',
      time: '~60s',
      icon: Layers,
    },
    {
      num: '04',
      tag: 'GO LIVE',
      title: 'Install WP & Launch',
      sub: 'Live on Web',
      time: 'Ready',
      icon: Rocket,
    },
  ];

  return (
    <section className="py-20 bg-slate-50/50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-slate-900 leading-tight">
            How It Works? Get Online in{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-indigo-600 to-teal-500">
              Under 3 Minutes
            </span>
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600">
            Follow our proven, lightning-fast onboarding roadmap built specifically for Indian businesses, startups,
            and creators.
          </p>
        </div>

        {/* 4 Interactive Step Buttons matching Screenshot 8 */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {steps.map((st, sIdx) => {
            const Icon = st.icon;
            const isSelected = activeStep === sIdx + 1;
            return (
              <button
                key={st.num}
                onClick={() => setActiveStep(sIdx + 1)}
                className={`p-4 rounded-2xl border text-left transition-all duration-200 flex items-center justify-between group ${
                  isSelected
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xl ring-2 ring-indigo-500/30'
                    : 'bg-white text-slate-700 border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className={`text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded ${
                        isSelected ? 'bg-indigo-900/60 text-indigo-300' : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {st.num} · {st.tag}
                    </span>
                  </div>
                  <div className="text-xs sm:text-sm font-bold truncate">{st.title}</div>
                  <div className="flex items-center gap-1.5 text-[10px] mt-1 text-slate-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 inline-block" />
                    <span>{st.sub}</span>
                  </div>
                </div>

                <div className="text-right shrink-0 ml-2">
                  <Icon
                    className={`w-6 h-6 mb-1 ${isSelected ? 'text-indigo-400' : 'text-slate-400 group-hover:text-slate-600'}`}
                  />
                  <span className="text-[10px] font-mono font-semibold text-slate-400 block">{st.time}</span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Active Step Showcase: Step 03 Automated Cloud Ops (Screenshot 8) */}
        <div className="rounded-3xl bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 border border-slate-800 p-6 sm:p-8 lg:p-10 shadow-2xl text-white">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Side: Descriptions */}
            <div className="lg:col-span-5 space-y-6">
              <span className="inline-block px-3 py-1 rounded-md text-[11px] font-mono font-bold uppercase tracking-wider bg-purple-950 text-purple-300 border border-purple-800">
                &gt;_ STEP 03 · AUTOMATED CLOUD OPS
              </span>

              <h3 className="text-2xl sm:text-3xl font-black text-white leading-tight">
                Instant 60s Container Spin-Up & NVMe Orchestration
              </h3>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                No manual waiting for human approval. Our orchestration software automatically provisions your
                isolated cPanel account on enterprise AMD EPYC™ processors with Gen4 NVMe storage.
              </p>

              {/* 3 Metric Pills */}
              <div className="grid grid-cols-3 gap-2.5 pt-1">
                <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 text-center">
                  <div className="text-[9px] uppercase tracking-wider text-slate-400">Provision Time</div>
                  <div className="text-sm font-black text-white font-mono mt-0.5">&lt; 45s</div>
                </div>
                <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 text-center">
                  <div className="text-[9px] uppercase tracking-wider text-slate-400">NVMe Speed</div>
                  <div className="text-sm font-black text-emerald-400 font-mono mt-0.5">7,000 MB/s</div>
                </div>
                <div className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 text-center">
                  <div className="text-[9px] uppercase tracking-wider text-slate-400">Anti-DDoS</div>
                  <div className="text-sm font-black text-cyan-400 font-mono mt-0.5">1 Tbps</div>
                </div>
              </div>

              {/* Bullet Points */}
              <div className="space-y-2.5 text-xs text-slate-300">
                {[
                  "Automated Free Let's Encrypt Wildcard SSL activation in seconds",
                  'Direct cPanel & Webmail credentials delivered to your inbox',
                  'Free white-glove site migration by certified hosting engineers',
                ].map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>

              <a
                href="#hosting-plans"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-md transition-all active:scale-95"
              >
                Check Server Specs <ArrowRight className="w-3.5 h-3.5" />
              </a>
            </div>

            {/* Right Side: Interactive Terminal Window */}
            <div className="lg:col-span-7 bg-slate-950 rounded-2xl p-5 border border-slate-800 shadow-2xl font-mono text-xs">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-slate-400">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500" />
                  <span className="w-2.5 h-2.5 rounded-full bg-yellow-500" />
                  <span className="w-2.5 h-2.5 rounded-full bg-green-500" />
                  <span className="text-[11px] ml-2 text-slate-300">gitysoft-cloud@bom-tier4:~#</span>
                </div>
                <button
                  onClick={handleRerun}
                  disabled={isRunning}
                  className="flex items-center gap-1 bg-purple-950 hover:bg-purple-900 text-purple-300 border border-purple-800 px-2.5 py-1 rounded text-[11px] transition-colors disabled:opacity-50"
                >
                  <RotateCcw className={`w-3 h-3 ${isRunning ? 'animate-spin' : ''}`} />
                  Re-run
                </button>
              </div>

              <div className="py-4 space-y-2 text-[11px]">
                {logs.slice(0, logIndex).map((log, lIdx) => (
                  <div key={lIdx} className="flex items-start gap-2">
                    <span className="text-slate-500">{log.time}</span>
                    <span className="text-slate-200 flex-1">{log.text}</span>
                    <span className={`font-bold ${log.color}`}>{log.status}</span>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                <span className="text-emerald-400 font-bold">
                  STATUS: Server Online & Credentials Dispatched
                </span>
                <span className="bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded text-[10px] font-bold">
                  100% HEALTH
                </span>
              </div>

              <div className="mt-3 pt-2 text-[10px] text-slate-500 flex items-center justify-between">
                <span>Location: Mumbai (MB1)</span>
                <span>Ping: 2.4 ms</span>
                <span>Uptime: 99.99%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
