import React, { useState } from 'react';
import { HOSTING_PLANS } from '../data/hostingData';
import { BillingCycle, Currency, HostingPlan } from '../types';
import { calculateEffectiveMonthlyPrice, formatCurrency } from '../utils/pricing';
import {
  Check,
  X,
  HelpCircle,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';

interface HostingPlansProps {
  currency: Currency;
  onOpenCheckout: (planName: string, price: number, cycle: BillingCycle) => void;
}

export const HostingPlans: React.FC<HostingPlansProps> = ({ currency, onOpenCheckout }) => {
  const [billingCycle, setBillingCycle] = useState<BillingCycle>('yearly');
  const [expandedPlanId, setExpandedPlanId] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    setExpandedPlanId(expandedPlanId === id ? null : id);
  };

  return (
    <section id="hosting-plans" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" /> Web Hosting Plans
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900">
            Speed-Optimized NVMe Web Hosting
          </h2>
          <p className="mt-3 text-base text-slate-600">
            LiteSpeed Web Server, HTTP/3, and free automated backups on enterprise Tier-4 Indian infrastructure.
          </p>

          {/* Billing Cycle Switcher */}
          <div className="mt-6 inline-flex items-center p-1.5 bg-slate-100 rounded-2xl border border-slate-200">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                billingCycle === 'monthly'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Monthly Billing
            </button>
            <button
              onClick={() => setBillingCycle('yearly')}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                billingCycle === 'yearly'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Annual Billing
              <span className="bg-amber-400 text-slate-950 text-[10px] px-1.5 py-0.2 rounded-full font-black uppercase">
                Save +10%
              </span>
            </button>
          </div>
        </div>

        {/* 4 Plans Grid matching Screenshot 9 */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-stretch">
          {HOSTING_PLANS.map((plan: HostingPlan) => {
            const isFeatured = plan.id === 'business';
            const effectivePrice = calculateEffectiveMonthlyPrice(plan.monthlyPrice, billingCycle);

            return (
              <div
                key={plan.id}
                className={`rounded-3xl flex flex-col justify-between transition-all duration-300 relative ${
                  isFeatured
                    ? 'border-2 border-purple-600 shadow-2xl bg-white ring-4 ring-purple-600/10 lg:-translate-y-2'
                    : 'border border-slate-200 bg-white shadow-md hover:shadow-xl hover:border-slate-300'
                }`}
              >
                {/* Most Popular Top Banner */}
                {plan.badge && (
                  <div className="w-full bg-purple-700 text-white text-[11px] font-extrabold uppercase py-1.5 px-4 text-center rounded-t-[22px] tracking-wider flex items-center justify-center gap-1">
                    ★ {plan.badge}
                  </div>
                )}

                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    {/* Header */}
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-extrabold text-slate-900">{plan.name}</h3>
                      {plan.discount && (
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-purple-100 text-purple-700">
                          {plan.discount}
                        </span>
                      )}
                    </div>

                    <p className="text-xs text-slate-500 mb-4 min-h-[32px] leading-relaxed">
                      {plan.description}
                    </p>

                    {/* Pricing Display */}
                    <div className="mb-4 pb-4 border-b border-slate-100">
                      <div className="text-xs text-slate-400 line-through">
                        {formatCurrency(plan.originalPrice, currency)}
                      </div>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="text-3xl font-black text-slate-950 font-mono tracking-tight">
                          {formatCurrency(effectivePrice, currency)}
                        </span>
                        <span className="text-xs text-slate-500 font-medium">/mo</span>
                      </div>
                      <span className="text-[11px] text-slate-400 block mt-1">Constant & Transparent Pricing</span>
                    </div>

                    {/* CTA Button */}
                    <button
                      onClick={() => onOpenCheckout(plan.name, effectivePrice, billingCycle)}
                      className={`w-full py-3 px-4 rounded-xl font-bold text-xs tracking-wide shadow-md transition-all active:scale-95 flex items-center justify-center gap-2 mb-2 ${
                        isFeatured
                          ? 'bg-gradient-to-r from-purple-600 via-pink-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white shadow-purple-500/25'
                          : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white'
                      }`}
                    >
                      Get Started Now <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <span className="text-[10px] text-center text-slate-400 block mb-6">
                      {plan.renewalPriceText}
                    </span>

                    {/* Perks & Inclusions */}
                    <div className="rounded-2xl bg-emerald-50/50 border border-emerald-100 p-3.5 mb-6 text-xs">
                      <div className="flex items-center gap-1.5 text-emerald-800 font-bold uppercase text-[10px] tracking-wider mb-2.5">
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        Perks & Inclusions
                      </div>
                      <div className="space-y-2">
                        {plan.perks.map((perk, pIdx) => (
                          <div key={pIdx} className="flex items-center justify-between text-[11px]">
                            <div className="flex items-center gap-1.5 text-slate-700">
                              {perk.isNegative ? (
                                <X className="w-3.5 h-3.5 text-red-400 shrink-0" />
                              ) : (
                                <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              )}
                              <span className={perk.isNegative ? 'line-through text-slate-400' : 'font-medium'}>
                                {perk.text}
                              </span>
                            </div>
                            {perk.badge && (
                              <span className="text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider bg-emerald-100 text-emerald-800 shrink-0">
                                {perk.badge}
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Hosting Resources */}
                    <div>
                      <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2.5">
                        <span>Hosting Resources</span>
                        <span className="text-[9px] lowercase font-normal text-slate-400">hover/tap info</span>
                      </div>
                      <div className="space-y-2 text-xs text-slate-700">
                        <div className="flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{plan.specs.websites}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{plan.specs.storage}</span>
                          </div>
                          <HelpCircle className="w-3 h-3 text-slate-400" />
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{plan.specs.emails}</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          {plan.specs.aiBuilder ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          ) : (
                            <X className="w-3.5 h-3.5 text-red-400 shrink-0" />
                          )}
                          <span className={!plan.specs.aiBuilder ? 'line-through text-slate-400' : ''}>
                            AI website builder
                          </span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{plan.specs.ftp}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{plan.specs.bandwidth}</span>
                          </div>
                          <HelpCircle className="w-3 h-3 text-slate-400" />
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{plan.specs.vcpu}</span>
                          </div>
                          <HelpCircle className="w-3 h-3 text-slate-400" />
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{plan.specs.ram}</span>
                          </div>
                          <HelpCircle className="w-3 h-3 text-slate-400" />
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>{plan.specs.ioLimit}</span>
                          </div>
                          <HelpCircle className="w-3 h-3 text-slate-400" />
                        </div>
                        <div className="flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{plan.specs.sqlDatabases}</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5">
                            <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                            <span>Addon Databases</span>
                          </div>
                          <span className="text-[9px] font-bold bg-purple-100 text-purple-700 px-1 rounded">
                            New
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Expandable More features */}
                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <button
                      onClick={() => toggleExpand(plan.id)}
                      className="w-full text-center text-xs font-semibold text-slate-600 hover:text-purple-600 flex items-center justify-center gap-1 py-1"
                    >
                      {expandedPlanId === plan.id ? 'Fewer features' : 'More features'}{' '}
                      {expandedPlanId === plan.id ? (
                        <ChevronUp className="w-3.5 h-3.5" />
                      ) : (
                        <ChevronDown className="w-3.5 h-3.5" />
                      )}
                    </button>

                    {expandedPlanId === plan.id && (
                      <div className="mt-3 pt-2 space-y-1.5 text-[11px] text-slate-600 border-t border-slate-100 animate-in fade-in duration-150">
                        <div className="flex justify-between">
                          <span>cPanel Control Suite:</span>
                          <span className="font-semibold text-emerald-600">Included</span>
                        </div>
                        <div className="flex justify-between">
                          <span>HTTP/3 & QUIC Enabled:</span>
                          <span className="font-semibold text-emerald-600">Yes</span>
                        </div>
                        <div className="flex justify-between">
                          <span>LSCache WordPress:</span>
                          <span className="font-semibold text-emerald-600">Pre-Configured</span>
                        </div>
                        <div className="flex justify-between">
                          <span>99.99% Uptime Guarantee:</span>
                          <span className="font-semibold text-emerald-600">SLA Backed</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Daily Off-site Backup:</span>
                          <span className="font-semibold text-emerald-600">JetBackup</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
