import React from 'react';
import { Currency } from '../types';
import { formatCurrency } from '../utils/pricing';
import { Check, X, Sparkles, ArrowRight, ShieldCheck, TrendingUp } from 'lucide-react';

interface PriceComparisonProps {
  currency: Currency;
  onOpenCheckout: (planName: string, price: number) => void;
}

export const PriceComparison: React.FC<PriceComparisonProps> = ({ currency, onOpenCheckout }) => {
  const comparisonRows = [
    {
      feature: 'Starting Price',
      gitysoft: formatCurrency(69, currency) + '/mo',
      godaddy: formatCurrency(199, currency) + '/mo',
      hostinger: formatCurrency(149, currency) + '/mo',
      bluehost: formatCurrency(299, currency) + '/mo',
      isText: true,
    },
    {
      feature: 'Free Domain',
      gitysoft: true,
      godaddy: false,
      hostinger: false,
      bluehost: false,
    },
    {
      feature: 'NVMe Storage',
      gitysoft: '10 GB',
      godaddy: '5 GB',
      hostinger: '10 GB',
      bluehost: '10 GB',
      isText: true,
    },
    {
      feature: 'Free SSL',
      gitysoft: true,
      godaddy: true,
      hostinger: true,
      bluehost: true,
    },
    {
      feature: 'Daily Backup',
      gitysoft: true,
      godaddy: false,
      hostinger: true,
      bluehost: true,
    },
    {
      feature: 'Business Email',
      gitysoft: true,
      godaddy: false,
      hostinger: true,
      bluehost: true,
    },
    {
      feature: '24/7 Support',
      gitysoft: true,
      godaddy: true,
      hostinger: true,
      bluehost: true,
    },
    {
      feature: 'Renewal Price',
      gitysoft: 'Same',
      godaddy: 'Higher',
      hostinger: 'Higher',
      bluehost: 'Higher',
      isRenewal: true,
    },
  ];

  return (
    <section id="price-comparison" className="py-20 bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="mb-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs font-bold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" /> Transparent Comparison
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-slate-900">
            Price Comparison
          </h2>
          <p className="mt-3 text-base text-slate-600">
            See how Gitysoft delivers industry-leading enterprise specs at up to 70% lower cost than traditional
            providers.
          </p>
        </div>

        {/* 2-Column Layout matching Screenshot 10 */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Table Container */}
          <div className="lg:col-span-8 overflow-x-auto rounded-3xl border border-slate-200 shadow-lg bg-white">
            <table className="w-full text-left text-xs sm:text-sm border-collapse min-w-[550px]">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/50">
                  <th className="py-4 px-4 sm:px-6 font-bold text-slate-700">Features</th>
                  <th className="py-4 px-4 sm:px-6 font-extrabold text-emerald-900 bg-emerald-50/70 border-x border-emerald-200/80 text-center">
                    <div className="text-base sm:text-lg">Gitysoft</div>
                    <span className="text-[10px] font-black uppercase tracking-wider bg-white text-emerald-700 px-2 py-0.5 rounded-full shadow-xs border border-emerald-200 inline-block mt-0.5">
                      Best Value
                    </span>
                  </th>
                  <th className="py-4 px-4 sm:px-6 font-bold text-slate-600 text-center">GoDaddy</th>
                  <th className="py-4 px-4 sm:px-6 font-bold text-slate-600 text-center">Hostinger</th>
                  <th className="py-4 px-4 sm:px-6 font-bold text-slate-600 text-center">Bluehost</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {comparisonRows.map((row, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-4 sm:px-6 font-semibold text-slate-800">{row.feature}</td>

                    {/* Gitysoft Highlighted Column */}
                    <td className="py-3.5 px-4 sm:px-6 text-center font-bold bg-emerald-50/40 border-x border-emerald-200/60 text-slate-900">
                      {row.isText ? (
                        <span className="font-mono">{row.gitysoft}</span>
                      ) : row.isRenewal ? (
                        <span className="text-emerald-700 font-extrabold">{row.gitysoft}</span>
                      ) : row.gitysoft ? (
                        <div className="w-5 h-5 mx-auto rounded-full bg-emerald-600 text-white flex items-center justify-center">
                          <Check className="w-3.5 h-3.5" />
                        </div>
                      ) : (
                        <div className="w-5 h-5 mx-auto rounded-full bg-slate-200 text-slate-400 flex items-center justify-center">
                          <X className="w-3.5 h-3.5" />
                        </div>
                      )}
                    </td>

                    {/* GoDaddy */}
                    <td className="py-3.5 px-4 sm:px-6 text-center text-slate-600">
                      {row.isText ? (
                        row.godaddy
                      ) : row.isRenewal ? (
                        <span className="text-red-500">{row.godaddy}</span>
                      ) : row.godaddy ? (
                        <Check className="w-4 h-4 text-emerald-500 mx-auto" />
                      ) : (
                        <X className="w-4 h-4 text-slate-300 mx-auto" />
                      )}
                    </td>

                    {/* Hostinger */}
                    <td className="py-3.5 px-4 sm:px-6 text-center text-slate-600">
                      {row.isText ? (
                        row.hostinger
                      ) : row.isRenewal ? (
                        <span className="text-red-500">{row.hostinger}</span>
                      ) : row.hostinger ? (
                        <Check className="w-4 h-4 text-emerald-500 mx-auto" />
                      ) : (
                        <X className="w-4 h-4 text-slate-300 mx-auto" />
                      )}
                    </td>

                    {/* Bluehost */}
                    <td className="py-3.5 px-4 sm:px-6 text-center text-slate-600">
                      {row.isText ? (
                        row.bluehost
                      ) : row.isRenewal ? (
                        <span className="text-red-500">{row.bluehost}</span>
                      ) : row.bluehost ? (
                        <Check className="w-4 h-4 text-emerald-500 mx-auto" />
                      ) : (
                        <X className="w-4 h-4 text-slate-300 mx-auto" />
                      )}
                    </td>
                  </tr>
                ))}

                {/* Bottom Row Action */}
                <tr className="bg-slate-50/80">
                  <td className="py-4 px-4 sm:px-6 font-bold text-xs text-slate-700">
                    High-Performance NVMe LiteSpeed Cloud
                  </td>
                  <td className="py-4 px-4 sm:px-6 text-center bg-emerald-50/50 border-x border-emerald-200">
                    <button
                      onClick={() => onOpenCheckout('Starter NVMe Hosting', 69)}
                      className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all active:scale-95 whitespace-nowrap inline-flex items-center gap-1.5"
                    >
                      Get Started <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </td>
                  <td className="py-4 px-4 sm:px-6 text-center text-slate-400">—</td>
                  <td className="py-4 px-4 sm:px-6 text-center text-slate-400">—</td>
                  <td className="py-4 px-4 sm:px-6 text-center text-slate-400">—</td>
                </tr>
              </tbody>
            </table>

            {/* Footnote */}
            <div className="p-3 sm:px-6 text-[11px] text-slate-500 flex flex-wrap items-center justify-between border-t border-slate-100 bg-slate-50/50">
              <span>* Pricing data regularly verified based on public rates.</span>
              <span className="font-semibold text-emerald-700">Guaranteed renewal lock-in</span>
            </div>
          </div>

          {/* Right Column: Maximum Value Card (Screenshot 10) */}
          <div className="lg:col-span-4 rounded-3xl bg-gradient-to-b from-emerald-50/90 via-teal-50/50 to-white border border-emerald-200 p-6 sm:p-8 shadow-xl">
            <span className="inline-block px-3 py-1 rounded-full text-[11px] font-extrabold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-300 mb-4">
              Maximum Value
            </span>

            <div className="flex items-center gap-2 mb-2">
              <span className="text-4xl font-black text-emerald-800 tracking-tight font-mono">SAVE UP TO</span>
              <span className="text-4xl font-black text-emerald-600 tracking-tight font-mono flex items-center">
                70% <TrendingUp className="w-7 h-7 ml-1" />
              </span>
            </div>

            <div className="text-xl font-bold text-slate-900 mb-3">with Gitysoft!</div>

            <p className="text-xs text-slate-600 leading-relaxed mb-6">
              Get high-speed NVMe storage, free SSL, and 24/7 dedicated support without the enterprise price tag.
            </p>

            <div className="space-y-3 mb-8 text-xs text-slate-700">
              {[
                'More Features & NVMe Storage',
                '24/7 Priority Support Included',
                'Significantly Lower Renewal Price',
                'No Hidden Charges or Lock-ins',
              ].map((bullet, bIdx) => (
                <div key={bIdx} className="flex items-center gap-2.5">
                  <div className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3" />
                  </div>
                  <span className="font-semibold">{bullet}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => onOpenCheckout('Switch to Gitysoft Migration', 69)}
              className="w-full py-3.5 px-4 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm tracking-wide shadow-lg shadow-emerald-600/25 transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              Switch & Save Today <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
