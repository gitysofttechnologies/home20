import React, { useState } from 'react';
import { Currency } from '../types';
import { formatCurrency } from '../utils/pricing';
import { X, Search, Globe, CheckCircle2, ArrowRight } from 'lucide-react';

interface DomainSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: Currency;
  onSelectDomain: (domain: string, price: number) => void;
}

export const DomainSearchModal: React.FC<DomainSearchModalProps> = ({
  isOpen,
  onClose,
  currency,
  onSelectDomain,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [isSearching, setIsSearching] = useState(false);

  if (!isOpen) return null;

  const tldResults = [
    { tld: '.in', price: 75, original: 499, available: true, badge: 'Popular in India' },
    { tld: '.com', price: 699, original: 999, available: true, badge: 'Global Standard' },
    { tld: '.co.in', price: 99, original: 399, available: true },
    { tld: '.org', price: 749, original: 1199, available: true },
    { tld: '.net', price: 799, original: 1299, available: true },
  ];

  const handleSearch = () => {
    if (!searchTerm.trim()) return;
    setIsSearching(true);
    setTimeout(() => {
      setIsSearching(false);
      setHasSearched(true);
    }, 500);
  };

  const cleanName = searchTerm.trim().toLowerCase().replace(/\.[a-z.]+$/, '') || 'mybrand';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-xl w-full border border-slate-200 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-5 bg-gradient-to-r from-blue-700 to-indigo-800 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Globe className="w-5 h-5 text-blue-200" />
            <div>
              <h3 className="text-base font-extrabold text-white">Find &amp; Register Your Domain</h3>
              <p className="text-xs text-blue-100">Live TLD Radar · Free DNS Zone Management Included</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Search Input */}
        <div className="p-5 sm:p-6 space-y-4">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Enter your brand or idea (e.g. freshfoods)"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium outline-hidden focus:border-blue-500 focus:bg-white transition-all"
              />
            </div>
            <button
              onClick={handleSearch}
              disabled={isSearching}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md transition-all active:scale-95 disabled:opacity-50"
            >
              {isSearching ? 'Checking...' : 'Search'}
            </button>
          </div>

          {/* Results list */}
          <div className="space-y-2 max-h-72 overflow-y-auto">
            {tldResults.map((item, idx) => {
              const fullDomain = `${cleanName}${item.tld}`;
              return (
                <div
                  key={idx}
                  className="p-3.5 rounded-2xl bg-slate-50 hover:bg-blue-50/50 border border-slate-200 hover:border-blue-300 transition-all flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-[11px] font-bold text-blue-600">
                      {item.tld}
                    </div>
                    <div>
                      <div className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                        {fullDomain}
                        {item.badge && (
                          <span className="text-[9px] font-extrabold uppercase px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800">
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Available for instant registration
                      </span>
                    </div>
                  </div>

                  <div className="text-right flex items-center gap-3">
                    <div>
                      <div className="text-sm font-black text-slate-900 font-mono">
                        {formatCurrency(item.price, currency)}
                        <span className="text-[10px] font-normal text-slate-500">/yr</span>
                      </div>
                      <div className="text-[10px] text-slate-400 line-through">
                        {formatCurrency(item.original, currency)}
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onSelectDomain(fullDomain, item.price);
                        onClose();
                      }}
                      className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-xs transition-all active:scale-95"
                    >
                      Select
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
          <span>Free WHOIS Privacy Protection &amp; Cloud DNS with every domain</span>
          <button
            onClick={onClose}
            className="text-xs font-semibold text-slate-700 hover:text-slate-900"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
