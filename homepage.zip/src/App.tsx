import React, { useState } from 'react';
import { Currency, BillingCycle } from './types';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { PillarCards } from './components/PillarCards';
import { HostingPlans } from './components/HostingPlans';
import { ArchitectureTabs } from './components/ArchitectureTabs';
import { PriceComparison } from './components/PriceComparison';
import { CloudVpsSection } from './components/CloudVpsSection';
import { DedicatedBareMetal } from './components/DedicatedBareMetal';
import { HowItWorksSteps } from './components/HowItWorksSteps';
import { WhyChooseUs } from './components/WhyChooseUs';
import { DigitalServicesGrid } from './components/DigitalServicesGrid';
import { GlobalInfrastructure } from './components/GlobalInfrastructure';
import { IndustriesAndReviews } from './components/IndustriesAndReviews';
import { FaqSection } from './components/FaqSection';
import { Footer } from './components/Footer';
import { CartCheckoutModal } from './components/CartCheckoutModal';
import { LiveChatDrawer } from './components/LiveChatDrawer';
import { VideoTourModal } from './components/VideoTourModal';
import { DomainSearchModal } from './components/DomainSearchModal';
import { FloatingActions } from './components/FloatingActions';

export default function App() {
  const [currency, setCurrency] = useState<Currency>('INR');

  // Modal & Drawer States
  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [selectedPlanName, setSelectedPlanName] = useState('Business Hosting');
  const [selectedPlanPrice, setSelectedPlanPrice] = useState(199.99);
  const [selectedBillingCycle, setSelectedBillingCycle] = useState<BillingCycle>('yearly');

  const [liveChatOpen, setLiveChatOpen] = useState(false);
  const [videoTourOpen, setVideoTourOpen] = useState(false);
  const [domainSearchOpen, setDomainSearchOpen] = useState(false);

  const handleOpenCheckout = (
    planName: string,
    price: number,
    cycle: BillingCycle = 'yearly'
  ) => {
    setSelectedPlanName(planName);
    setSelectedPlanPrice(price);
    setSelectedBillingCycle(cycle);
    setCheckoutModalOpen(true);
  };

  const handleSelectService = (serviceName: string) => {
    if (serviceName.includes('Domain')) {
      setDomainSearchOpen(true);
    } else if (serviceName.includes('Web Hosting')) {
      const el = document.getElementById('hosting-plans');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else if (serviceName.includes('VPS')) {
      const el = document.getElementById('cloud-vps');
      el?.scrollIntoView({ behavior: 'smooth' });
    } else {
      const el = document.getElementById('digital-services');
      el?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans selection:bg-blue-600 selection:text-white">
      {/* 1. Header with announcement, navigation, currency toggle */}
      <Header
        currency={currency}
        setCurrency={setCurrency}
        onOpenCheckout={handleOpenCheckout}
        onOpenLiveChat={() => setLiveChatOpen(true)}
        onOpenDomainSearch={() => setDomainSearchOpen(true)}
      />

      <main>
        {/* 2. Hero Section (Screenshot 14) with GMB Lead Scraper & 11-Service Strip */}
        <HeroSection
          currency={currency}
          onOpenCheckout={handleOpenCheckout}
          onOpenDomainSearch={() => setDomainSearchOpen(true)}
          onSelectService={handleSelectService}
        />

        {/* 3. 3 Spotlight Feature Cards (Screenshot 15: Cloud VPS, Titan Email, Ecommerce) */}
        <PillarCards currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 4. Speed-Optimized NVMe Web Hosting Plans (Screenshot 9) */}
        <HostingPlans currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 5. Choose Your Cloud Architecture & cPanel Suite (Screenshot 12) */}
        <ArchitectureTabs currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 6. Transparent Price Comparison (Screenshot 10) */}
        <PriceComparison currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 7. High-Performance Cloud VPS (Screenshot 13) */}
        <CloudVpsSection currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 8. Enterprise Dedicated Servers & Bare Metal (Screenshot 11) */}
        <DedicatedBareMetal currency={currency} onOpenCheckout={handleOpenCheckout} />

        {/* 9. How It Works - Under 3 Minutes (Screenshot 8) */}
        <HowItWorksSteps />

        {/* 10. Why Choose Gitysoft & Data Center Tour (Screenshot 1 & 5) */}
        <WhyChooseUs
          onOpenVideoTour={() => setVideoTourOpen(true)}
          onOpenLiveChat={() => setLiveChatOpen(true)}
        />

        {/* 11. Complete Digital Growth Ecosystem Grid (Screenshot 2) */}
        <DigitalServicesGrid
          currency={currency}
          onOpenCheckout={handleOpenCheckout}
          onOpenDomainSearch={() => setDomainSearchOpen(true)}
        />

        {/* 12. Global Infrastructure & Datacenter Edge Network (Screenshot 3 & 4) */}
        <GlobalInfrastructure onOpenCheckout={handleOpenCheckout} />

        {/* 13. Industries We Serve & Customer Reviews Carousel (Screenshot 6) */}
        <IndustriesAndReviews />

        {/* 14. Frequently Asked Questions (Screenshot 7) */}
        <FaqSection
          onOpenLiveChat={() => setLiveChatOpen(true)}
          onOpenEmailSupport={() => setLiveChatOpen(true)}
        />
      </main>

      {/* 15. Comprehensive Footer */}
      <Footer />

      {/* Interactive Global Modals and Drawers */}
      <CartCheckoutModal
        isOpen={checkoutModalOpen}
        onClose={() => setCheckoutModalOpen(false)}
        planName={selectedPlanName}
        basePrice={selectedPlanPrice}
        initialCycle={selectedBillingCycle}
        currency={currency}
      />

      <LiveChatDrawer
        isOpen={liveChatOpen}
        onClose={() => setLiveChatOpen(false)}
        onSelectPlan={handleOpenCheckout}
      />

      <VideoTourModal
        isOpen={videoTourOpen}
        onClose={() => setVideoTourOpen(false)}
      />

      <DomainSearchModal
        isOpen={domainSearchOpen}
        onClose={() => setDomainSearchOpen(false)}
        currency={currency}
        onSelectDomain={(domain, price) => handleOpenCheckout(`Domain: ${domain}`, price)}
      />

      {/* Floating Action Buttons (Back to Top & 24/7 Live Support) */}
      <FloatingActions onOpenLiveChat={() => setLiveChatOpen(true)} />
    </div>
  );
}
